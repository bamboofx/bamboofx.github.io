#import package
from sklearn import datasets
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error,explained_variance_score
from sklearn.utils import shuffle

# load dữ liệu từ datasets
data=datasets.load_boston()
# thử xáo trộn data để chúng ta không nhầm lẫn dữ liệu phân tích:
X,y=shuffle(data.data,data.target,random_state=7)
# Chia dataset để train và test
num_training = int(0.8*len(X))
X_train,y_train=X[:num_training],y[:num_training]
X_test,y_test=X[num_training:],y[num_training:]
# Tạo và train SVR sử dụng một nhân tuyến tính (linear kernel). Tham số C dùng để thay thế/phạt cho dữ liệu train bị lỗi. nếu bạn tăng giá trị của C, model sẽ tốt hơn và trùng hơn với dữ liệu training. Nhưng nó cũng có thể làm Overfitting(quá mức phù hợp - trong Supervised Learning chúng ta chỉ cần xấp xỉ) và sẽ mất tính tổng quát. Tham số epsilon được coi như là một ngưỡng ( threshold); nó không bỏ qua cho dữ liệu train lỗi nếu giá trị dự đoán trong khoảng này so với giá trị thực tế:
sv_regressor=SVR(kernel='linear',C=1.0,epsilon=0.1)
sv_regressor.fit(X_train,y_train)
# Đánh giá hiệu suất của hồi quy và in các số liệu
y_test_pred=sv_regressor.predict(X_test)
mse=mean_squared_error(y_test,y_test_pred)
evs=explained_variance_score(y_test,y_test_pred)
print("\n Performance")
# sai số toàn phương trung bình MSE của một phép dự đoán là trung bình của bình phương các sai số, tức là sự khác biệt giữa các dự đoán và những gì được đánh giá. MSE là hàm rủi ro
print("Sai số toàn phương trung bình =",round(mse,2))
# Điểm phương sai
print("Điểm phương sai =", round(evs,2))
# Lấy một data để kiểm thử và lấy kết quả dự đoán
test_data=[3.7,0,18.4,1,0.87,5.95,91,2.5052,26,666,20.2,351.34,15.27]
print("\n Dự đoán giá nhà:",sv_regressor.predict([test_data])[0])
