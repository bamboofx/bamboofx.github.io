import numpy as np
import matplotlib.pyplot as plt
from  sklearn.metrics import classification_report

def visualize_classifier(classifier, X, y,title=''):
        # Define the minimum and maximum values for X and Y
        # that will be used in the mesh grid
        min_x, max_x = X[:, 0].min() - 1.0, X[:, 0].max() + 1.0
        min_y, max_y = X[:, 1].min() - 1.0, X[:, 1].max() + 1.0
        # Define the step size to use in plotting the mesh grid
        mesh_step_size = 0.01
        # Define the mesh grid of X and Y values
        x_vals, y_vals = np.meshgrid(np.arange(min_x, max_x, mesh_step_size),
        np.arange(min_y, max_y, mesh_step_size))
        # Run the classifier on the mesh grid
        output = classifier.predict(np.c_[x_vals.ravel(), y_vals.ravel()])
        # Reshape the output array
        output = output.reshape(x_vals.shape)
        # Create a plot


        plt.figure()
        # plt title;
        plt.title(title)
        # Choose a color scheme for the plot
        plt.pcolormesh(x_vals, y_vals, output, cmap=plt.cm.gray)
        # Overlay the training points on the plot
        plt.scatter(X[:, 0], X[:, 1], c=y, s=75, edgecolors='black',linewidth=1, cmap=plt.cm.Paired)
        # Specify the boundaries of the plot
        plt.xlim(x_vals.min(), x_vals.max())
        plt.ylim(y_vals.min(), y_vals.max())
        # Specify the ticks on the X and Y axes
        plt.xticks((np.arange(int(X[:, 0].min() - 1), int(X[:, 0].max() + 1),
                              1.0)))
        plt.yticks((np.arange(int(X[:, 1].min() - 1), int(X[:, 1].max() + 1),
                              1.0)))
        plt.show()
def report_print(classifier,class_names,X_train,y_train,y_test,y_test_pred):
    print("\n" + "#" * 40)
    print("\nClassifier performance on training dataset\n")
    print(classification_report(y_train, classifier.predict(X_train),target_names=class_names))
    print("#" * 40 + "\n")
    print("#" * 40)
    print("\nClassifier performance on test dataset\n")
    print(classification_report(y_test, y_test_pred, target_names=class_names))
    print("#" * 40 + "\n")
def visualize_clusters(X,labels,title=''):
    plt.figure()
    colors='rgbcmykw'
    markers = '.,ov^<>12348spP*hH+xXdD|_'
    num_clusters = len(np.unique(labels))
    markers=markers[0:num_clusters]
    colors=colors[0:num_clusters]
    for i, marker in zip(range(num_clusters), markers):
        plt.scatter(X[labels == i, 0], X[labels == i, 1], marker=marker, color=colors[i])
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    # print(x_min,x_max)
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    plt.title=title
    plt.xlim(x_min,x_max)
    plt.ylim(y_min,y_max)
    plt.xticks()
    plt.yticks()
    plt.show()