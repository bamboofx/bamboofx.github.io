import numpy as np

from sklearn import preprocessing
from sklearn.svm import LinearSVC
from sklearn.multiclass import OneVsOneClassifier
from sklearn import model_selection
# Chúng ta xử dụng file income_data.txt làm dữ liệu. file này chứa dữ liệu thu nhập chi tiết:
input_file ="data/income_data.txt"
# Theo thứ tự tải dữ liệu từ file, chúng ta cần xử lý nó trước vì vậy nên chúng ta sẽ cần chuẩn bị để phân loại. Chúng ta sẽ dùng 25000 điểm dữ liệu cho mỗi lớp:
X=[]
y=[]
count_class1=0
count_class2=0
max_datapoints=25000
# Mở file và bắt đầu đọc các dòng
with open(input_file,'r') as f:
	for line in f.readlines():
		if count_class1>=max_datapoints and count_class2>=max_datapoints:
			break;
		if '?' in line:
			continue
# mỗi dòng được chia ra bằng dấu phẩy vì thế chúng ta cần chia nó một cách phù hợp. thành phần cuối cùng trong mỗi dòng đại diện cho nhãn. Dựa trên nhãn đó chúng ta sẽ chỉ định nó vào một lớp:

		data=line[:-1].split(', ')
		if data[-1]=='<=50K' and count_class1<max_datapoints:
			X.append(data)
			count_class1 +=1
		if data[-1]=='>50K' and count_class2<max_datapoints:
			X.append(data)
			count_class2 +=1

# convert X list này dưới dạng numpy array chúng ta đã có dữ liệu đầu vào cho hàm sklearn
X=np.array(X)

# nếu có bất kỳ thuộc tính nào là string ( dữ liệu chữ), khi đó chúng ta cần mã hóa nó. Nếu dữ liệu là số chúng ta có thể giữ nó lại. Chú ý chúng ta kết thúc cùng với nhiều nhãn được mã hóa và chúng ta cần theo dõi tất cả chúng:
label_encoder = []
X_encoded = np.empty(X.shape)
for i,item in enumerate(X[0]):
	if item.isdigit():
		X_encoded[:, i] = X[:, i]
	else:
		label_encoder.append(preprocessing.LabelEncoder())
		X_encoded[:, i] = label_encoder[-1].fit_transform(X[:, i])
		print(X[:, i])
X = X_encoded[:, :-1].astype(int)
y = X_encoded[:, -1].astype(int)

Z=[[2,3,1],[4,5,1],[6,7,1]]
Z=np.array(Z)
D=Z[:,-1]
#print(X[:,len(X[0])])
for i,mitem in enumerate(label_encoder[-2].classes_):
	print(mitem,"-->",i)


print(label_encoder[-1].transform(['<=50K']))
# Tạo lớp phân loại SVM  với một linear kernel
classifier=OneVsOneClassifier(LinearSVC(random_state=0))
# train classifier
classifier.fit(X,y)
# Thực hiện xác nhận chéo sử dụng cách chia 80/20 để training và testing, sau đó dự đoán kết quả đầu ra cho dữ liệu được training:
# xác nhận chéo
X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y,test_size=0.2, random_state=5)
classifier = OneVsOneClassifier(LinearSVC(random_state=0))
classifier.fit(X_train, y_train)
y_test_pred = classifier.predict(X_test)
# Tính toán kết quả  F1 cho phân loại :
f1=model_selection.cross_val_score(classifier,X,y,scoring='f1_weighted',cv=2)
print("Đẻ lần F1: " + str(round(100*f1.mean(),2))+"%")
# giờ thì classifier đã sẵn sang, hãy xem làm thế nào để lấy ngẫu nhiên một dữ liệu điểm đầu vào và dự đoán kết quả đầu ra. Định nghĩa một điểm data đầu vào như sau:
# đoán dữ liệu đầu ra cho một datapoint test:
input_data = ['36', 'Private', '215646', 'Some-college', '9', 'Married-civ-spouse','Prof-specialty', 'Husband', 'White', 'Male', '0', '0', '40','Vietnam']
# Trước khi ta thực hiện dự đoán, chúng ta cần mã hóa dữ liệu này bằng cách sử dụng mã hóa nhãn mà chúng ta đã tạo từ trước:
input_data_encoded = [-1] * len(input_data)
count = 0
for i, item in enumerate(input_data):
	if item.isdigit():
		input_data_encoded[i] = int(input_data[i])
	else:
		d=[input_data[i]]
		input_data_encoded[i] = int(label_encoder[count].transform(d))
		count += 1

input_data_encoded=np.array(input_data_encoded)

# Giờ thì chúng ta đã sẵn sang để dự đoán kết quả đầu ra sử dụng classifier:
predict_classifier=classifier.predict([input_data_encoded])
print(label_encoder[-1].inverse_transform(predict_classifier)[0])