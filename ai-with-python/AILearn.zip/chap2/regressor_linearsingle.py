# import các package cần thiết.
import numpy as np

import pickle
from sklearn import linear_model
import sklearn.metrics as sm
import matplotlib.pyplot as plt
# Chúng ta xử dụng dữ liệu trong file data_singlevar_regr.txt. Đây là dữ liệu nguồn của chúng ta
input_file="data/data_singlevar_regr.txt"
# file dữ liệu được ngăn cách bởi dấu , ở mỗi dòng nên chúng ta load và parse data
data=np.loadtxt(input_file,delimiter=',')
X,y=data[:,:-1],data[:,-1]
# chia dữ liệu (split data) để training và testing:
num_training=int(0.8*len(X))
num_text=len(X)-num_training
# Training data
X_train,y_train=X[:num_training],y[:num_training]
X_test,y_test=X[num_training:],y[num_training:]
#Tạo một object hồi quy tuyến tính và train nó xử dụng training data:
regressor=linear_model.LinearRegression()
regressor.fit(X_train,y_train)
#dự đoán kết quả đầu ra cho dữ liệu kiểm tra xử dụng training model:
y_test_pred=regressor.predict(X_test)
# Vẽ đồ thị kết quả đầu ra xử dụng plot(plt)
plt.scatter(X_test,y_test,color='green')
plt.plot(X_test,y_test_pred,color='black',linewidth=4)
plt.xticks(())
plt.yticks(())
plt.show()
# Tính toán số liệu hiệu suất cho object hồi quy (regressor bằng cách so sánh với đầu ra thực sự (ground truth, cùng với đầu ra đã dự đoán (predicted outputs):
# In tính toán số liệu hiệu suất
print("Linear regressor performance:")
print("Mean absolute error =", round(sm.mean_absolute_error(y_test,y_test_pred), 2))
print("Mean squared error =", round(sm.mean_squared_error(y_test,y_test_pred), 2))
print("Median absolute error =", round(sm.median_absolute_error(y_test,y_test_pred), 2))
print("Explain variance score =", round(sm.explained_variance_score(y_test,y_test_pred), 2))
print("R2 score =", round(sm.r2_score(y_test, y_test_pred), 2))
# Khi mô hình đã được tạo chúng ta có thể lưu nó lại dưới dạng 1 file và dùng lại sau. Python có một công cụ gọi là pickle để chúng ta làm việc đó:
output_model_file='model.pkl'
with open(output_model_file,'wb') as f:
	pickle.dump(regressor,f)
# giờ thì load model từ file và biểu diễn dự đóan:
with open(output_model_file,'rb') as f:
	regressor_model=pickle.load(f)
y_test_pred_new=regressor_model.predict(X_test)
print("\n New mean absolute error=", round(sm.mean_absolute_error(y_test,y_test_pred_new),2))
