# import package
import numpy as np
from sklearn import linear_model
import matplotlib.pyplot as plt
import sklearn.metrics as sm
from sklearn.preprocessing import PolynomialFeatures
# chúng ta xử dụng file data_multivar_regr.txt để làm dữ liệu
input_file ='data/data_multivar_regr.txt'
data=np.loadtxt(input_file,delimiter=',')
X,y=data[:,:-1],data[:,-1]
# chia data để training và test
num_training=int(0.8*len(X))
num_test=len(X)-num_training

X_train,y_train=X[:num_training],y[:num_training]
X_test,y_test=X[num_training:],y[num_training:]
# tạo linear regressor model:
linear_regressor=linear_model.LinearRegression()
linear_regressor.fit(X_train,y_train)

y_test_pred=linear_regressor.predict(X_test)

print(X_test[-1],y_test[-1])


print("Linear Regressor performance:")
print("Mean absolute error =", round(sm.mean_absolute_error(y_test,y_test_pred), 2))
print("Mean squared error =", round(sm.mean_squared_error(y_test,y_test_pred), 2))
print("Median absolute error =", round(sm.median_absolute_error(y_test,y_test_pred), 2))
print("Explained variance score =",round(sm.explained_variance_score(y_test, y_test_pred), 2))
print("R2 score =", round(sm.r2_score(y_test, y_test_pred), 2))

#Tạo một đa thức hồi quy(polynomial regression)  bậc 10. Train Hồi quy object này trên training dataset. Lấy một mẫu thử và xem nó thực hiện dự đoán thế nào. Bước đầu tiên là phải chuyển đổi nó thành một đa thức (polynomial):
polynomial=PolynomialFeatures(degree=10)
X_train_transformed=polynomial.fit_transform(X_train)
datapoint=[[7.75,6.35,5.56]]
poly_datapoint=polynomial.fit_transform(datapoint)
# Bạn hãy để ý datapoint này khá giống với datapoint ở dòng 11 trong file txt dữ liệu [7.66,6.29,5.66]. Vậy thì phép hồi quy tốt sẽ dự đoán một kết quả đầu ra gần với số 41.35, Tạo một phép hồi quy tuyến tính (linear regressor) và biểu diễn đa thức . Biểu diễn dự đoán xử dụng cả  hồi quy tuyến tính và hồi quy đa thức (linear and polynomial regressor) để xem sự khác biệt
poly_linear_model=linear_model.LinearRegression()
poly_linear_model.fit(X_train_transformed,y_train)
print("\n Linear regression:\n", linear_regressor.predict(datapoint))
print("\n Polynomial regression:\n",poly_linear_model.predict(poly_datapoint))
y_linear_pred=linear_regressor.predict(datapoint)
y_poly_pred=poly_linear_model.predict(poly_datapoint)
