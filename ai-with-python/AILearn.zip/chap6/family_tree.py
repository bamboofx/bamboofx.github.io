import json
from kanren import Relation,facts,run,conde,var,eq

# Tạo một hàm để kiểm tra nếu X là cha mẹ của Y chúng ta sẽ sử dụng suy luận nếu X là cha mẹ cảu y thì X cũng đông thời là cha hoặc mẹ. nếu chúng ta định nghĩa "Bố" hay "Mẹ" vào bên trong fact:
# khởi tạo mối quan hệ father và mother
father=Relation()
mother=Relation()
def parent(x,y):
    return conde([father(x,y)],[mother(x,y)])

# Tạo một hàm để kiểm tra nếu x là ông bà của y. sau đó chúng ta sẽ suy ra là nếu x là ông bà của y thì có nghĩa là con của x là bố mẹ của y
def grandparent(x,y):
    temp=var()
    return conde((parent(x,temp),parent(temp,y)))

#Tạo một hàm nếu x là anh chị em của y. Chúng ta sẽ sử dụng logic nếu x là anh chị em của y thì suy ra x,y có cùng cha mẹ. Chú ý khi chúng ta liệt kê tất cả danh sách anh chị em của x. thì
# x cũng được liệt kê bởi vì x cũng thỏa mãn các điều kiện so sánh. Vì thế khi chúng ta in ra kết quả chúng ta phải loại bỏ x trong danh sách:
def sibling(x,y):
    temp=var()
    return conde((parent(temp,x),parent(temp,y)))
# Tạo hàm để kiểm tra nếu x là chú của y. Chúng ta sẽ tính toán logic là nếu x là chú của y, thì ông bà của x sẽ là bố mẹ của y. Chú ý ở đây là khi chúng ta liệt kế tất cả danh sách
# chú của x, thì bố của x cũng thỏa mãn điều kiện. Vì thế chúng ta sẽ phải loại bỏ bố của x ra khỏi danh sách các ông chú
def uncle(x,y):
    temp=var()
    return conde((father(temp,x),grandparent(temp,y)))
# Tạo hàm main:
if __name__=='__main__':
    #Load data từ file json
    with open("data/chap6/relationships.json") as f:
        d=json.loads(f.read())
        for item in d['father']:
            facts(father,(list(item.keys())[0],list(item.values())[0]))
        for item in d['mother']:
            facts(mother,(list(item.keys())[0],list(item.values())[0]))

    # tạo biến x
    x=var()
    # Giờ thì thử đặt vài câu hỏi và tìm xem bộ giải mã của chúng ta có trả lời đúng không
    name='John'
    ouput=run(0,x,father(name,x))
    print("Danh sách con của ",name,"là :")
    for item in ouput:
        print(item)
    # Tìm mẹ cho william
    name='William'
    output=run(0,x,mother(x,name))
    print("Danh sách mẹ của ",name,"là")
    for item in output:
        print(item)

    #Tìm ông bà của Wayne
    name='Wayne'
    output=run(0,x,grandparent(x,name))
    print("ông bà của ",name)
    for item in output:
        print(item)
    # Tìm các cháu của Megan
    name='Megan'
    output=run(0,x,grandparent(name,x))
    print("Danh sách cháu của ",name,"là")
    for item in output:
        print(item)
    # Liệt kê các cặp vợ chồng
    a,b,c=var(),var(),var()
    output=run(0,(a,b),(father,a,c),(mother,b,c))
    print("Danh sách các cặp vợ chồng")
    for item in output:
        print("Chồng: ",item[0],"\t\t<==>\t\t ","Vợ: ",item[1])

