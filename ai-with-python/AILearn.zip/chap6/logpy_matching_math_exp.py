from kanren import run,var,fact
import kanren.assoccomm as la

#Tạo hai phép tính toán học cơ bản
add='addition'
mul='multiplication'
# Hai phép cộng(add) và nhân(mul là hai phép tính có tính chất giao hoán(commutative) và kết hợp(associative). thử tính nào:
fact(la.commutative,mul)
fact(la.associative,mul)
fact(la.commutative,add)
fact(la.associative,add)
# Tạo ra một vài biến :
a,b,c=var('a'),var('b'),var('c')
# ta xét thử biểu thức sau:
#expression_orig=3*(-2)+(1+2*3)x(-1)
# giơ thì thử ẩn vài biến trong biểu thức
# ta có biểu thức 1 expression1=(1+2*a)*b+3*c
# biểu thức 2 expression2=c*3+bx(2*a+1)
# biểu thức 3 expression3=(((2*a)*b)+b+3*c
# Các mày hãy thử quan sát xem có thấy cả ba biểu thức đều biểu hiện một biểu thức cơ bản. Nhiệm vụ của chúng ta là kết hợp các biểu thức cùng với biểu thức cơ bản để tìm những biến ẩn không biết
# Tạo biểu thức với code
original_expression=(add,(mul,3,-2),(mul,(add,1,(mul,2,3)),-1))
expression1=(add,(mul,(add,1,(mul,2,a)),b),(mul,3,c))
expression2 = (add, (mul, c, 3), (mul, b, (add, (mul, 2, a), 1)))
expression3 = (add, (add, (mul, (mul, 2, a), b), b), (mul, 3, c))
# So sánh các biểu thức cùng với biểu thức mẫu. Phương thức run thường được sử dụng trong karen. phương thức này lấy tham số input và chạy các biểu thức.
# Tham số đầu tiên đầu tiên là số của giá trị, tham số thứ 2 là một biến, và tham số thứ 3 là một hàm
k1=run(0,(a,b,c),la.eq_assoccomm(expression1,original_expression))
k2=run(0,(a,b,c),la.eq_assoccomm(expression2,original_expression))
k3=run(0,(a,b,c),la.eq_assoccomm(expression3,original_expression))
print(k1)
print(k2)
print(k3)