from kanren import *
from kanren.core import lall

# Tạo biến people
people=var()
# Tạo luật dùng half lall. luật đầu tiên ở đây là ta có 4 người, và các thông tin khác
rules=lall(
    # Khai báo 4 người
    (eq,(var(),var(),var(),var()),people),
    # Người đầu tiên là Tèo thằng này có cái xe màu xanh
    (membero,('Tèo',var(),'Xanh',var()),people),
    # Thông tin thứ 2: thằng này có mèo và sống ở Lào
    (membero,(var(),'Mòe',var(),'Lào'),people),
    # Thông tin thứ 3: cu Tý sống ở Đông lào
    (membero,('Tý',var(),var(),'Đông Lào'),people),
    # Thông tin thứ 4: thằng đi xe đen sống ở Thái
    (membero, (var(), var(), 'Đen', 'Thái'), people),
    # Thông tin thứ 5: Sửu nuôi mèo
    (membero, ('Sửu', 'Mòe', var(), var()), people),
    # Thông tin thứ 6: Dần ở Thái
    (membero, ('Dần', var(), var(), 'Thái'), people),
    #Thông tin thứ 7: Nuôi chó sống ở Tàu
    (membero, (var(), 'Chó', var(), 'Tàu'), people),
    # Câu hỏi ở đây là thằng thỏ sống ở đâu,ai nuôi nó
    (membero, (var(), 'Thỏ', var(), var()), people),
    # Thêm thông tin cho đẹp đội hình
    (membero, (var(), 'Chim Cu', var(), var()), people),
    (membero, (var(), var(), 'Trắng', var()), people),
    (membero, (var(), var(), 'Vàng', var()), people)
)
# Thử chạy phần giải quyết vấn đề xem thế nào
# Gồm 3 biến run(n,x,*goals)
solutions=run(0,people,rules)

# lấy thông tin từ solutions :\ Lấy thông tin từ solutions đầu tiên[0]
output=[house for house in solutions[0] if 'Thỏ' in house]
# Lấy vị trí từng solution sẽ có dạng như ta đã đặt trên rules và output là thông tin chứa nhà có con thỏ có dạng [('Tý', 'Thỏ', var(), 'Đông Lào')]
print("Thằng nuôi thỏ là thằng: "+output[0][0])
attrs=['Tên','Thú Nuôi','Màu Xe',"Quốc gia"]

# Giờ thì in thử tất cả các solution ra xem
for i in solutions:
    print('\n' + '\t\t'.join(attrs))
    print("=" * 50)
    for item in i:
        print('')
        print('\t\t\t'.join([str(x) for x in item]))
