import kanren.core as kc
import itertools as it
from kanren import membero,isvar
from sympy.ntheory.generate import prime,isprime
# Tiếp theo tạo một hàm để kiểm tra số được cho có phải là số nguyên tố hay không dựa trên dạng của dữ liệu. Nếu nó kiểu số thì mọi việc đơn giản. Nếu nó không phải số chúng ta phải chạy một cách hàm lại
# Hàm conde là cấu trúc cung cấp các phép toán AND và OR
# Hàm condeseq giống như conde nhưng nó hỗ trợ lặp:
def check_prime(x):
    if isvar(x):
        return kc.condeseq([(kc.eq,x,p)] for p in map(prime,it.count(1)))
    else:
        return kc.success if isprime(x) else kc.fail

# Tạo biến x để sử dụng
x=kc.var()
# tạo một dãy số và check nếu sô đó là số nguyên tố hay không
# hàm membero kiểm tra nếu một số đã cho là một phần trong danh sách các số được chỉ định trong tham số đầu vào:
list_num=(23,4,27,17,13,10,21,29,3,32,11,19)
print("Danh sách của các nguyên tố")
print(set(kc.run(0,x,(membero,x,list_num),(check_prime,x))))
# Dùng hàm trên theo cách khác
print("7 số nguyên tố đàu tiên: ")
print(kc.run(7,x,check_prime(x)))
