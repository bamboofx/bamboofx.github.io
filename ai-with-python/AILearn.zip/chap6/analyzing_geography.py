from kanren import run,fact,eq,Relation,var
# Tạo mối quan hệ tập mối quan hệ
adjacent=Relation()
coastal=Relation()
# Load File Data  chứa dữ liệu các tỉnh ven biển
with open("data/chap6/coastal_provinces.txt",'r',encoding='utf8') as f:
    line=f.read()
    coastal_provinces=line.split(',')
    for province in coastal_provinces:
        #Duyệt tất cả các tỉnh ven biển và đưa thông tin vào trong cơ sở thực tế ( put information to the fact)
        #print(province)
        fact(coastal,province)
    # Load File Data chứa dữ liệu các tỉnh nằm kề nhau
with open("data/chap6/adjacent_provinces.txt",'r',encoding='utf8') as f:
    adj_list=[line.strip().split(',') for line in f if line and line[0].isalpha()]
    #print(adj_list)
    # Thêm thông tin tỉnh liền kề vào trong fact base
for L in adj_list:
    head,tail=L[0],L[1:]
    for province in tail:
        fact(adjacent,head,province)
# Tạo biến x và y
x=var()
y=var()
# Giờ thì chạy đc rồi hỏi thằng ngu này vài câu xem nào
#Tỉnh Nam Định Có gần Thái Bình?
output=run(0,x,adjacent('Nam Định','Ninh Bình'))
print("Tỉnh Nam Định Có gần Thái Bình?: ")
print('Có' if len(output) else 'Không')
# Các tỉnh tiếp giáp Hà Nội
output=run(0,x,adjacent('Hà Nội',x))
print("Các tỉnh tiếp giáp Hà Nội")
for province in output:
    print(province)
#
print("Liệt kê các tỉnh ven biển nằm gần Hồ Chí Minh")
output=run(0,x,adjacent("Hồ Chí Minh",x),coastal(x))
for province in output:
    print(province)
print("Liệt kê các tỉnh nằm giữa Đà Nẵng Và Quảng Nam")
output=run(0,x,adjacent('Đà Nẵng',x),adjacent('Quảng Nam',x))
if len(output):
    for province in output:
        print(province)
else:
    print("Méo Có")

print("Liệt kê 7 tỉnh giáp một tỉnh ven biển")
n=7
output=run(n,x,coastal(y),adjacent(x,y))
if len(output):
    for province in output:
        print(province)
else:
    print("Méo có")

