class MyCLass: pass
