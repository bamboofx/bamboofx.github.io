import os
import argparse
import warnings

import numpy as np
from scipy.io import wavfile

from hmmlearn import hmm
from features import mfcc

# Tạo class để train sử dụng HMM:
class ModelHMM(object):
    def __init__(self,num_components=4,num_iter=1000):
        self.n_iter=num_iter
        self.n_components=num_components
        self.cov_type='diag'
        self.model_names='GaussianHMM'
        # Tạo biến làm nơi chúng ta sẽ lưu những model của từng từ
        self.models=[]
        self.model=hmm.GaussianHMM(n_components=self.n_components,covariance_type=self.cov_type,n_iter=self.n_iter)
    #Tạo hàm để train model
    def train(self,training_data):
        np.seterr(all='ignore')
        cur_model=self.model.fit(training_data)
        self.models.append(cur_model)
    #Tạo một hàm để tính toán điểm số cho dữ liệu đầu vào:
    def compute_score(self,input_data):
        return self.model.score(input_data)
#Tạo một hàm để xây dựng một model cho mỗi từ trong dữ liệu training
def build_models(input_folder):
    speech_models=[]
    # phân tích dữ liệu thư mục input:
    for dir_name in os.listdir(input_folder):
        #Lấy tên của sub foler
        subfolder=os.path.join(input_folder,dir_name)
        if not os.path.isdir(subfolder):
            continue
        # Lấy nhãn
        label=subfolder[subfolder.rfind('\\')+1:]
        # Tạo biến X để lưu dữ liệu train
        X=np.array([])
        # Tạo list file sử dụng để train
        training_files=[x for x in os.listdir(subfolder) if x.endswith('.wav')][:-1]
        # Tạo vòng lặp tới khi train xong và xây dựng được models
        for mfilename in training_files:
            file_path=os.path.join(subfolder,mfilename)
            # Lấy tín hiệu (signal) âm thanh từ file hiện tại
            sampling_freq,signal=wavfile.read(file_path)
            # Tách các MFCC features
            #print(len(signal),sampling_freq)
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                features_mfcc = mfcc(signal, sampling_freq)
            if len(X)==0:
                X=features_mfcc
            else:
                X=np.append(X,features_mfcc,axis=0)
        model=ModelHMM()
        model.train(X)
        speech_models.append((model,label))
        model=None
    return speech_models
# Tạo hàm để chạy thử nghiệm treen dữ liệu test:
def run_test(tes_files):
    # Phân loại dữu liệu input
    for test_file in tes_files:
        sampling_freq,signal=wavfile.read(test_file)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            feature_mfcc=mfcc(signal,sampling_freq)
        #Tạo số điểm max_score ở mức âm vô cùng và nhãn dự đoán
        max_score=-float('inf')
        predicted_label=None
        for item in speech_models:
            model,label=item
            score=model.compute_score(feature_mfcc)
            if score>max_score:
                # Chọn điểm tại mức điểm lớn nhất hiện tại trong số tất cả model
                max_score=score
                predicted_label=label
        start_index=test_file.find('\\')+1
        end_index=test_file.rfind('\\')

        #print(test_files)
        original_label=test_file[start_index:end_index]
        print('Tên gốc:',original_label)
        print('Tên dự đoán: ',predicted_label)

#Tạo hàm main
if __name__=='__main__':
    input_folder=input('datafolder')
    speech_models=build_models(input_folder)
    # Chúng ta đã để lại 1 file để test trong mỗi folder. giờ thì ta sử dụng file đó để tính độ chính xác của model
    test_files=[]
    for root,dirs,files in os.walk(input_folder):
        for filename in(x for x in files if '15' in x):
            filepath=os.path.join(root,filename)
            test_files.append(filepath)
    run_test(test_files)

