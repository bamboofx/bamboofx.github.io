import json
import numpy as np
import matplotlib.pyplot as plt

from scipy.io.wavfile import write

# Tạo một hàm để tạo ra một tone (cao độ node âm thanh) dựa trên những tham số như tần số, thời gian, biên độ, tần số hz
def tone_synthesizer(freq,duration,amplitude=1.0,sampling_freq=44100):
    time_axis=np.linspace(0,duration,int(duration*sampling_freq))

    # Xây dựng cấu trúc tín hiệu âm thanh sử dụng những tham số được chỉ định và trả về giá trị dưới dạng npint16
    signal=amplitude*np.sin(2*np.pi*freq*time_axis)
    return signal.astype(np.int16)

if __name__=="__main__":
    file_tone_single='fa.wav'#input("Tên file muốn lưu")
    file_tone_sequence='generated_tone_sequence.wav'
    # Chúng ta sử dụng file chứa tone map chứa tên nốt (tone node - La Si Do) để tạo tần số âm thanh
    mapping_file='../data/chap12/tone_mapping.json'
    # Tải file vào lấy tonemap từ file
    with open(mapping_file,'r') as f:
        tone_map=json.loads(f.read())
    #Tạo nốt Fa (F) trong 3 giây:
    tone_name='D'
    duration=0.5
    amplitude=12000
    sampling_freq=44100
    # lấy tần số tương ứng từ map
    tone_freq=tone_map[tone_name]
    # Tạo tone sử dụng hàm tổng hợp đã tạo bên trên
    synthesized_tone=tone_synthesizer(tone_freq,duration,amplitude,sampling_freq)
    write(file_tone_single,sampling_freq,synthesized_tone)
    # Thử tạo một chuỗi nốt nhạc để làm cho âm thanh hay hơn.
    #Tạo chuỗi nốt âm thanh với thời gian tương ứng
    tone_squence=[('G',0.4),('G',0.4),('G',0.4),('C',0.6),('G',0.4),('G',0.4),('G',0.4),('G',0.4),('C',0.8),('D',0.4)]
    # Xây dựng âm thanh dựa trên chuỗi nốt âm thanh
    signal=np.array([])
    for item in tone_squence:
        tone_name=item[0]
        freq=tone_map[tone_name]
        duration=item[1]
        print(freq, duration, amplitude, sampling_freq)
        synthesized_tone=tone_synthesizer(freq,duration,amplitude,sampling_freq)
        signal=np.append(signal,synthesized_tone)
    write(file_tone_sequence,sampling_freq,signal.astype(np.int16))
    #
    signal=signal[2000:5000]
    plt.figure()
    time_axis = 1000 * np.arange(0, len(signal), 1) / float(sampling_freq)  # Trục X
    plt.plot(time_axis,signal)
    plt.show()