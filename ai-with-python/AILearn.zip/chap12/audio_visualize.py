import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile

# đọc file audio đã tạo sẵn. bạn có thể dùng window recoder hoặc recoder của điện thoại để lưu file dưới dạng wave
# Sử dụng hàm wavefile.read. Nó sẽ trả về 2 giá trị.
#       sampling frequency - tần số lấy mẫu
#       audio signal- tín hiệu âm thanh
sampling_freq,signal=wavfile.read("../data/chap12/abc.wav")
# In ra terminal dạng của tín hiệu, định dạng dữ liệu, và thời gian của tín hiệu âm thanh
print("Dạng tín hiệu: ",signal.shape)
print("Định dạng dữ liệu (datatype): ",signal.dtype)
print("Thời gian của tín hiệu âm thanh: ",round(signal.shape[0]/float(sampling_freq),2)," giây")
# Đơn giản lại tín hiệu âm thanh
signal=signal/np.power(3,5)
# Tách lấy khoảng 500 giá trị từ tín hiệu âm thanh để biểu diễn đồ thị (tại vì tín hiệu âm thanh của mình đoạn đầu là không có nên tín hiệu sẽ thẳng ----- nên mình sẽ lấy từ giây thứ 0.1 :
signal=signal[24500:25000]
# Xây dựng cột thời gian
time_axis=1000*np.arange(0,len(signal),1)/float(sampling_freq)
# Biểu diễn tín hiệu âm thanh
plt.plot(time_axis,signal,color='black')
plt.xlabel('Thời gian(mili giây)')
plt.ylabel('Biên độ')
plt.title('Biểu diễn tín hiệu âm thanh')
plt.show()