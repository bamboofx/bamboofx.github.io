import numpy as np
import matplotlib.pyplot as plt

from scipy.io import wavfile
from features import mfcc,logfbank

# Load wave file
sampling_freq,signal=wavfile.read('../data/chap12/apple01.wav')
# Lấy 10,000 mẫu đầu tiên trong signal để phân tích

signal=signal[:10000]

# dùng hàm mfcc để phân tích MFCC
features_mfcc=mfcc(signal,sampling_freq)
# In tham số MFCC ra terminal:
print('MFCC:\nSố lượng ô =',features_mfcc.shape[0])
print('Độ lớn của mỗi features =',features_mfcc.shape[1])
#Vẽ các tính năng (features) MFCC
features_mfcc=features_mfcc.T
plt.matshow(features_mfcc)
plt.title('MFCC')

#Phân tách các bộ lọc
features_fb=logfbank(signal,sampling_freq)
print('Bộ lọc:\nSố lượng ô: =',features_fb.shape[0])
print('Độ lớn của mỗi features =',features_fb.shape[1])
#Vẽ lên biểu đồ
features_fb=features_fb.T
plt.matshow(features_fb)
plt.title('Filter Bank')
plt.show()
