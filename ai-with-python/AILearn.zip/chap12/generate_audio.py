import numpy as np
import matplotlib.pyplot as plt
from scipy.io.wavfile import write

# Định nghĩa tên cho file đầu ra
output_file='generated_audio.wav'
# Xác định một vài tham số như độ dài, tần số mẫu, tần số cao độ, giá trị thấp nhất và giá trị cao nhất
duration=4 # Đây là tính giây
sampling_freq=44100# Tính theo Hz
tone_freq=784
min_val=-4*np.pi
max_val=4*np.pi
#Tạo tín hiệu âm thanh sử dụng những tham số trên
t=np.linspace(min_val,max_val,duration*sampling_freq)
signal=np.sin(2*np.pi*tone_freq*t)
# Tạo thêm độ nhiễu cho âm thanh (lên xuoogns 1 tẹo)
noise=1001.1*np.random.rand(duration*sampling_freq)
signal+=noise
# Giảm cường độ âm thanh và kéo dãn tín hiệu
scaling_factor=np.power(2,15)-1
signal_normalize=signal/np.max(np.abs(signal))
signal_scaled=np.int16(signal_normalize*scaling_factor)
# Ghi tín hiệu âm thanh thành file
write(output_file,sampling_freq,signal_scaled)

# vẽ tín hiệu âm thanh thành biểu đồ
# Chỉ lấy 200 giá trị đầu tiên để biểu diễn cho đẹp
signal=signal[:200]
time_axis=1000*np.arange(0,len(signal),1)/float(sampling_freq) #Trục X
plt.figure()
plt.plot(time_axis,signal,color='red')
plt.xlabel('Time milisecond')
plt.ylabel('Biên độ')
plt.title('Âm thanh được tạo bằng code')
plt.show()