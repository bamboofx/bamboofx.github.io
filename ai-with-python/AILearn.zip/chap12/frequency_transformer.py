import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile

# Tải file phát âm từ apple hoặc bạn có thể dùng file tao.wav bằng tiếng việt
sampling_freq,signal=wavfile.read('../data/chap12/tao.wav')
# Normalize tín hiệu âm
signal=signal/np.power(2,15)
# Lấy độ dài của signal và chia nửa lấy 1/2
len_signal=len(signal)
len_half=np.ceil((len_signal+1)/2.0).astype(np.int)
# áp dụng biến đổi Fourier Transform
freq_signal=np.fft.fft(signal)
# Giảm tần số tín hiệu và lấy bình phương của nó
freq_signal=abs(freq_signal[0:len_half])/len_signal
freq_signal**=2
# chia tín hiệu biến đổi thành chẵn và lẻ
len_fts=len(freq_signal)
if len_signal%2:
    freq_signal[1:len_fts]*=2
else:
    freq_signal[1:len_fts-1]*=2
# tính độ lớn của tín hiệu đo bằng dB (decibel)
signal_power=10*np.log10(freq_signal)
# Tạo trục x đây là trục tần số được đo bằng kHz (kilog hertz):
x_axis=np.arange(0,len_half,1)*(sampling_freq/len_signal)/1000.0
# Vẽ đồ thị
plt.figure()
plt.plot(x_axis,signal_power,color='red')
plt.title('Biến đổi tín hiệu âm thanh')
plt.xlabel('Tần số (kHz)')
plt.ylabel('Độ lớn (dB)')
plt.show()
