import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from sklearn import datasets
from sklearn.neighbors import KNeighborsClassifier

# lấy dữ liệu từ file chap5/data.txt
data=np.loadtxt("data/chap5/data.txt",delimiter=',')
X,y=data[:,:-1],data[:,-1].astype(np.int)
# Vẽ dữ liệu nhập
plt.figure()
plt.title("Dữ liệu input")
marker='v^os'
marker=[marker[i] for i in y]

for i in range(X.shape[0]):
    plt.scatter(X[i,0],X[i,1],marker=marker[i],s=75,edgecolors='r',facecolors='none')

# Định nghĩa số điểm lân cận mà ta muốn lấy
num_neighbors=12
# Định nghĩa khoảng cách mỗi ô lưới mà chúng ta sẽ vẽ
grid_step=0.01
# Tọa một bộ phân loại K_nearest Neigbors
classifier=KNeighborsClassifier(n_neighbors=num_neighbors,weights='distance')
# Train mô hình
classifier.fit(X,y)
# tạo một lưới giá trị mà ta sẽ sử dụng để vẽ đồ thị
x_min,x_max=X[:,0].min()-1,X[:,0].max()+1
y_min,y_max=X[:,1].min()-1,X[:,1].max()+1
x_values,y_values=np.meshgrid(np.arange(x_min,x_max,grid_step),np.arange(y_min,y_max,grid_step))
# Đánh giá bộ phân loại trên tất cả các điểm trên lưới để vẽ đồ thị
output=classifier.predict(np.c_[x_values.ravel(),y_values.ravel()])
output=output.reshape(x_values.shape)
plt.figure()
plt.pcolormesh(x_values,y_values,output,cmap=cm.Paired)

# Phủ dữ liệu train lên lưới
for i in range(X.shape[0]):
    plt.scatter(X[i,0],X[i,1],marker=marker[i],s=50,edgecolors="c",facecolors='none')
# Đặt giới hạn trục X và Y
plt.xlim(x_values.min(),x_values.max())
plt.ylim(y_values.min(),y_values.max())
plt.title('Mô hình phân loại K Nearest Neighbors')
# Tạo một testpoint để xem bộ phân loại làm việc
test_datapoint=[5.1,3.6]
# Tạo đò thị cùng với dữ liệu trên ning và kiểm thử testpoint xem nó nằm ở chỗ nào
plt.figure()
plt.title('Test point')
for i in range(X.shape[0]):
    plt.scatter(X[i,0],X[i,1],marker=marker[i],s=80,edgecolors='black',facecolors='none')
    plt.scatter(test_datapoint[0],test_datapoint[1],marker='x',s=200,facecolors='black')
#Tách điểm dữ liệu lân cận K (K Nearét Neighbors) để test dữ liệu dựa trên mô hình phân loại:
_,indices=classifier.kneighbors([test_datapoint])
indices=indices.astype(np.int)[0]
# Vẽ điểm K lân cận lên biểu đồ
plt.figure()
plt.title('K Nearest Neighbors')
for i in indices:
    plt.scatter(X[i,0],X[i,1],marker=marker[i],linewidths=3,s=100,facecolors='g')
# Biểu diễn điểm dữ liệu test
plt.scatter(test_datapoint[0],test_datapoint[1],marker='x',linewidths=10,s=200,edgecolors='r')
# Bểu diễn dữ liệu input
for i in range(X.shape[0]):
    plt.scatter(X[i,0],X[i,1],marker=marker[y[i]],s=75,edgecolors='b',facecolors='none')
# Print dữ liệu ra terminal
print('Predict output',classifier.predict([test_datapoint])[0])
plt.show()
