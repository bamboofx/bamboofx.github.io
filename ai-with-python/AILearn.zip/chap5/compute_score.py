import argparse
import json
import numpy as np
# Xây dựng mộ bộ phân tích cú pháp xử lý tham số input. nó sẽ chấp nhận 2 người dùng và dạng điểm số nó cần đử sử dụng tính toán điểm tương đồng:
def build_arg_parser():
    paser=argparse.ArgumentParser(description='Tính toán điểm tương đồng')
    paser.add_argument('--user1',dest='user1',required=True,help='First User')
    paser.add_argument('--user2',dest='user2',required=True,help='Second User')
    paser.add_argument('--score-type',dest='score_type',required=True,choices=['Euclidean','Pearson','Both'],help='Sử dụng thước đo nào')
    return paser
# Tạo một hàm để tính toán điểm số Euclidean giữa 2 dùng. Nếu người dùng không có trong dữ liệu thì báo lỗi
def euclidean_score(dataset,user1,user2):
    if user1 not in dataset:
        raise TypeError(' Không tìm thấy '+ user1+'Trong bảng dữ liệu ')
    if user2 not in dataset:
        raise TypeError(' Không tìm thấy '+ user2+'Trong bảng dữ liệu ')
    # Tạo một object để theo dõi phim được đánh giá bởi cả 2 user:
    common_movies={}
    # Tách những bộ phim được đánh giá bởi 2 user:
    for item in dataset[user1]:
        if item in dataset[user2]:
            common_movies[item]=1
    # Nếu không có phim nào gióng nhau chúng ta không thể tính toán điểm số:
    if len(common_movies) ==0:
        return 0
    # Tính sai số giữa các xếp hạng và dùng nó để tính điểm số Euclidean:
    square_diff=[]
    for item in dataset[user1]:
        if item in dataset[user2]:
            square_diff.append(np.square(dataset[user1][item]-dataset[user2][item]))
    return 1/(1+np.sqrt(np.sum(square_diff)))
# Tạo một hàm để tính điểm số Pearson giữa 2 số
def pearson_score(dataset,user1,user2):
    if user1 not in dataset:
        raise TypeError(' Không tìm thấy '+ user1+'Trong bảng dữ liệu ')
    if user2 not in dataset:
        raise TypeError(' Không tìm thấy '+ user2+'Trong bảng dữ liệu ')

    common_movies={}
    for item in dataset[user1]:
        if item in dataset[user2]:
            common_movies[item]=1
    num_ratings=len(common_movies)
    if num_ratings==0:
        return 0
    user1_sum=np.sum([dataset[user1][item] for item in common_movies])
    user2_sum = np.sum([dataset[user2][item] for item in common_movies])
    user1_square_sum=np.sum([np.square(dataset[user1][item]) for item in common_movies])
    user2_square_sum=np.sum([np.square(dataset[user2][item]) for item in common_movies])
    sum_of_products=np.sum([dataset[user1][item]*dataset[user2][item] for item in common_movies])
    # Tính toán những tham số khác nhau để tính điểm số Pearson sử dụng những kết quả bên trên
    Sxy=sum_of_products-(user1_sum*user2_sum)/num_ratings
    Sxx=user1_square_sum-np.square(user1_sum)/num_ratings
    Syy=user2_square_sum-np.square(user2_sum)/num_ratings
    # Nếu không có độ sai lệch thì điểm số =0 :
    if Sxx*Syy==0:
        return 0
    # trả về điểm số Pearson
    return Sxy/np.sqrt(Sxx*Syy)
# Tạo hàm Main để gán tham số khi chạy file python
if __name__=='__main__':
    args=build_arg_parser().parse_args()
    user1=args.user1
    user2=args.user2
    score_type=args.score_type
    ratings_file='data/chap5/ratings.json'
    with open(ratings_file,'r')as f:
        data=json.loads(f.read())
        if score_type=='Euclidean':
            print('Điểm số Euclidean:')
            print(euclidean_score(data,user1,user2))
        elif score_type=='Pearson':
            print('Điểm số Pearson:')
            print(pearson_score(data,user1,user2))
        else:
            print('Điểm số Pearson:')
            print(pearson_score(data, user1, user2))
            print('Điểm số Euclidean:')
            print(euclidean_score(data, user1, user2))

