import argparse
import json
import numpy as np

from compute_score import pearson_score

# Tạo một hàm để lấy tham số đầu vào.
def build_arg_parser():
    parser=argparse.ArgumentParser(description='Tìm film cho thằng này')
    parser.add_argument('--user',dest='user',required=True,help='Input User')
    return parser
# Tạo một hàm để lấy phim gợi ý cho thằng vừa nhập. nếu thằng này không tồn tại trong cơ sở dữ liệu thì báo lỗi:
def get_recommendations(dataset,user):
    if user not in dataset:
        raise TypeError('Không có thằng '+user+" Trong cơ sở dữ liệu")
    # Tạo biến để theo dõi điểm:
    overall_scores={}
    similarity_scores={}
    for u in [x for x in dataset if x!=user]:
        similarity_score=pearson_score(dataset,user,u)
        #Nếu điểm số similarity nhỏ hơn hoặc bằng 0, thì tìm thằng user khác trong dataset:
        if similarity_score<=0:
            continue
        # Lấy danh sách phim mà thằng user vừa lấy được đã bầu chọn nhưng thằng input chưa bầu chọn:
        filtered_list=[x for x in dataset[u] if x not in dataset[user] or dataset[user][x]==0]
        # Lặp lại để tìm kiếm trong filtered_líst theo dõi để đánh giá dựa trên điểm similarity_score. Và cũng đặt một item vào object similarity_scores
        for item in filtered_list:
            overall_scores.update({item:dataset[u][item]*similarity_score})
            similarity_scores.update({item:similarity_score})
        # Nếu không có phim nào giống nhau thì chúng ta không thể gợi ý cái giề cả:
        if len(overall_scores)==0:
            return ['Không có gợi ý phim nào cho thằng này']
        # Đơn giản hóa số điểm dựa trên điểm similarity:
        movie_scores=np.array([[score/similarity_scores[item],item] for item,score in overall_scores.items()])
        # Sắp xếp điểm số và lấy phim gợi ý:
        movie_scores=movie_scores[np.argsort(movie_scores[:,0])[::-1]]
        movie_recommends=[movie for _,movie in movie_scores]
        return movie_recommends
# Tạo hàm main để lấy tham số input:
if __name__=="__main__":
    args=build_arg_parser().parse_args()
    user=args.user
    # Lấy dữ liệu từ file
    with open("data/chap5/ratings.json",'r') as f:
        data=json.loads(f.read())
        movies=get_recommendations(data,user)
        print('Danh sách phim đề cử cho thằng',user,'là')
        for i,movie in enumerate(movies):
            print(str(i + 1),'. ',movie)
