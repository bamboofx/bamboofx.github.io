from sklearn.datasets import samples_generator
from sklearn.feature_selection import SelectKBest,f_regression
from sklearn.pipeline import Pipeline
from sklearn.ensemble import ExtraTreesRegressor
# Giờ thì hãy tạo một vài nhãn từ dữ liệu cho trước để train và test. Trong scikit-learn có một functions có thể thực hiện nó.
# Trong chỗ này chúng ta sẽ tạo 150 điểm dữ liệu, tại mỗi điểm dữ liệu có một vector 25 chiều.
# Những số trong mỗi vector này sẽ được tạo ra bằng cách sử dụng một bộ tạo số ngẫu nhiên. Mỗi điểm dữ liệu có 6 thông tin tính năng và không có tính năng thừa.
#n_sample điểm dữ liệu
#n_feature số vector trong điểm dữ liệu
#n_class số lớp
#n_informative số thông tin trên điểm dữ liệu

X,y=samples_generator.make_classification(n_samples=150,n_features=25,n_classes=3,n_informative=6,n_redundant=0,random_state=7)

# Khối đầu tiên trong đường ống là bộ chọn tính năng. Khối này sẽ chọn số K tính năng tốt nhất.
# Hãy đặt giá trị của số K là 9
k_best_selector=SelectKBest(f_regression,k=9)
# Khối tiếp theo trong đường ống là một bộ phân loại Extremely Random Forest
#n_estimator số lần ước tính
#max_depth độ cao lớn nhất của cây phân loại
classifier=ExtraTreesRegressor(n_estimators=60,max_depth=4)

# Giờ thì xây dựng một đường ống bằng cách nối những khối riêng biệt bên trên chúng ta đã tạo. Chúng ta có thể đặt tên cho từng khối để theo dõi:

processor_pipeline=Pipeline([('selector',k_best_selector),('erf',classifier)])

# Chúng ta có thể thay đổi tham số của những nhóm riêng biệt này. Hãy thử thay đổi giá trị của số K trong khối đầu tiên thành 7 và số lần tính của khối 2 thành 30.
# Chúng ta sẽ dụng tên chúng ta đã gán phần trước để làm:
processor_pipeline.set_params(selector__k=5,erf__n_estimators=30)
# Train đường ống này sử dụng dữ liệu ví dụ
processor_pipeline.fit(X,y)
# Dự đoán kết quả đầu ra cho tất cả dữ liệu nhập và in nó:
output=processor_pipeline.predict(X)
print('Dự đoán đầu ra:',output)
# Tính điểm sử dụng nhãn dữ liệu đã dduwwocj gán
print("Điểm số: ",processor_pipeline.score(X,y))
# Phân tách những tính năng được chọn bởi bộ chọn khối. Chúng ta chỉ định chúng ta muốn chọn 7 tính năng trong số 25 tính năng
status=processor_pipeline.named_steps['selector'].get_support()
print(status)
selected=[i for i,x in enumerate(status) if x]
print("Chỉ số của các tính năng được chọn: ",', '.join(str(x) for x in selected))
