import  numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import NearestNeighbors

# Tạo một bộ dữ liệu 2D
X=np.array([[2.1,1.3],[1.3, 3.2], [2.9, 2.5], [2.7, 5.4], [3.8, 0.9],[7.3, 2.1],[4.2, 6.5], [3.8, 3.7], [2.5, 4.1], [3.4, 1.9],[5.7, 3.5], [6.1, 4.3], [5.1, 2.2], [6.2, 1.1]])
# Định nghĩa một điểm nearest neighbors chúng ta muốn tách
k=5
# tạo một bộ dữ liệu test
test_datapoint=[4.3,2.7]
# Vẽ dữ liệu input
plt.figure()
plt.title("Dữ liệu nhập")
plt.scatter(X[:,0],X[:,1],marker='o',s=75,color='r')

# Tạo và huấn luyện một mô hình điểm K Nearest Neigbors sử dụng dữ liệu nhập.
knn_model=NearestNeighbors(n_neighbors=k,algorithm='ball_tree')
knn_model.fit(X)
# Sử dụng mô hình này để tách dữ liệu nearest neighbors dựa trên điểm dữ liệu test
distance,indices=knn_model.kneighbors([test_datapoint])
print('K Nearest Neighbors')
for rank,i in enumerate(indices[0][:k],start=1):
    print(str(rank)+"==>",X[i])

# Vẽ đồ thị điểm gần nhất:
plt.figure()
plt.title('Nearest neighbors')
plt.scatter(X[:,0],X[:,1],marker='o',s=75,color='r')
plt.scatter(X[indices][0][:][:, 0], X[indices][0][:][:, 1],marker='H',s=350,color="c",facecolor='none')
plt.scatter(test_datapoint[0],test_datapoint[1],marker='x',s=75,color='y')
plt.show();