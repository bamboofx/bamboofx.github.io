import argparse
import json
import numpy as np
from compute_score import pearson_score
# Tạo một hàm để tách tham số input. Chỉ có một tham số input để lấy tên của người dùng:
def build_arg_parser():
    parser=argparse.ArgumentParser(description="Tìm user giống với thằng này")
    parser.add_argument('--user',dest='user',required=True,help='Thằng input')
    return parser

#Tạo một hàm để tìm người dùng trong bộ dữ liệu giống với thằng vừa input. Nếu thằng đó không có trong dữ liệu thì báo lỗi:
def find_similar_users(dataset,user,num_user):
    if user not in dataset:
        raise TypeError('Méo tìm thấy thằng '+user+' trong cơ sở dữ liệu')
# Chúng ta đã import hàm để tính điểm số Pearson. Giờ dùng hàm đó để tính thằng input với những thằng khác trong dataset:
    score=np.array([[x,pearson_score(dataset,user,x)] for x in dataset if x != user])
# Sắp xếp điểm theo thứ tự giảm dần và lấy giá trị thấp nhất
    scores_sortted=np.argsort(score[:,1])[::-1]
# Tách số lượng num_user hàng đầu bởi tham số input ban đầu và return array:
    top_user=scores_sortted[:num_user]
    return score[top_user]
# Tạo hàm main để nhận tách tham số đầu vào.
if __name__=='__main__':
    args=build_arg_parser().parse_args()
    user=args.user
# Lấy dữ liệu từ file rating.json. File này có tên và bầu chọn của họ cho những bộ phim khác nhau.
    with open("data/chap5/ratings.json",'r') as f:
        data=json.loads(f.read())
# Tim 3 user những thằng mà giống nhất với user được chỉ định bởi tham số input. Bạn có thể thay đổi số lượng tùy ý. Và in tên những thằng đó ra cùng với điểm số:
        print('Những thằng user có bình chọn giống thằng '+user)
        similar_user=find_similar_users(data,user,3)
        print('User\t\t\t\t\tĐiểm số')
        print('-'*41)
        for item in similar_user:
            print(item[0],'\t\t\t',round(float(item[1]),2))
