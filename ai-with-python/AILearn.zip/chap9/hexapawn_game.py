from easyAI import TwoPlayersGame,AI_Player,Human_Player,Negamax
# tạo class để control game. Bắt đầu bằng cách định nghĩa số lượng tốt ở mỗi bên và độ dài rộng của bàn cờ. Tạo một list tuples chứa vị trí
class GameController(TwoPlayersGame):
    def __init__(self,players,size=(4,4)):
        self.size=size
        num_pawns,len_board=size
        p = [[(i, j) for j in range(len_board)] for i in [0, num_pawns - 1]]
        print(p,num_pawns,len_board)
        #Tạo hướng đi, đích đến và gắn những con chốt cho mỗi player"
        for i, d, goal, pawn in [(0, 1, num_pawns - 1, p[0]), (1, -1, 0, p[1])]:
            print(i)
            print('d=',d)
            print(goal)
            print(pawn)
            players[i].direction=d
            players[i].goal_line=goal
            players[i].pawns=pawn
        self.players=players
        self.nplayer=1
        # Tạo bảng chữ cái để dễ xác định vị trí quân cờ (giống bàn cờ vua A1-A2...
        self.alphabets='ABCDEFGHIJ'
        # tạo 2 hàm lambda để chuyển đổi string <-> tuples
        self.to_tuples = lambda s: (self.alphabets.index(s[0]), int(s[1:]) - 1)
        self.to_string = lambda move: ' '.join([self.alphabets[move[i][0]] + str(move[i][1] + 1) for i in (0, 1)])
    def possible_moves(self):
        # Tạo hàm move để tính những bước đi có thể:
        moves=[]
        # Vị trí quân tốt của đối thủ
        opponent_pawns=self.opponent.pawns
        d=self.player.direction
        # Khi không nhìn thấy quân tốt của đối thủ ở một vị trí thì có nghĩa đó là nơi có thể đi:
        for i,j in self.player.pawns:
            if(i+d,j) not in opponent_pawns:
                moves.append(((i,j),(i+d,j)))
            if(i+d,j+1) in opponent_pawns:
                moves.append(((i,j),(i+d,j+1)))
            if(i+d,j-1) in opponent_pawns:
                moves.append(((i,j),(i+d,j-1)))
        return list(map(self.to_string,[(i,j) for i,j in moves]))
    def make_move(self,move):
        move=list(map(self.to_tuples,move.split(' ')))
        ind=self.player.pawns.index(move[0])
        self.player.pawns[ind]=move[1]
        # Loại bỏ tốt của đối thủ khi thấy nó trên đường đi:
        if move[1] in self.opponent.pawns:
            self.opponent.pawns.remove(move[1])
    def loss_condition(self):
        return (any([i==self.opponent.goal_line for i,j in self.opponent.pawns])) or(self.possible_moves()==[])
    def is_over(self):
        return self.loss_condition()
    def show(self):
        f=lambda x:'x' if x in self.players[0].pawns else('o' if x in self.players[1].pawns else '.')
        print('\n'.join([" ".join([f((i,j))
                         for j in range(self.size[1])])
                         for i in range(self.size[0])]))

# Hàm khởi tạo
if __name__=="__main__":
    scoring=lambda game:-100 if game.loss_condition() else 0
    algorithm = Negamax(12,scoring)
    game=GameController([Human_Player(),AI_Player(algorithm)])
    game.play()
    symbol="XO"
    print("Kết quả: ",symbol[game.nopponent-1], " Thắng sau",game.nmove,"bước")

