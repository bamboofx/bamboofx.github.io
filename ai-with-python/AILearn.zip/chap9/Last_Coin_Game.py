from easyAI import TwoPlayersGame,id_solve,Human_Player,AI_Player
from easyAI.AI import TT
#Tạo một class ddeer quản lý các phép toán trong game. Chúng sẽ thừa kế từ class TwoPlayerGame trong thư viện eassyAI. Chúng có 2 tham số được định nghĩa
# Tham số thứ 1 là player chúng ta sẽ nói về giá trị của object player sau
class LastCoinStand(TwoPlayersGame):
    def __init__(self,players):
        #Tạo tham số player. đây là tham số bắt buộc
        self.players=players
        # Để định nghĩa ai là người bắt đầu trò chơi thì số người chơi bắt đầu từ 1. nên người bắt đầu trò chơi sẽ là 1
        self.nplayer=1
        # tạo số lượng coin để chơi. Bạn có thể chọn tùy ý ở đây tôi chọn 27
        self.num_coin=27
        # Tạo số coin lớn nhất có thể lấy đi trong mỗi bước đi. có thể chọn tùy ý và tôi chọn là 4
        self.max_coin=13
        # tạo số nước đi có thể. trong trường hợp này người chơi có thể lấy đi 1,2,3,4 coin trong mỗi nước đi
    def possible_moves(self):
        return [str(x) for x in range(1,self.max_coin+1)]
    # Tạo một hàm để loại bỏ số coin đã được lấy và tính số lượng coin còn lại trong đống coin
    def make_move(self,move):
        self.num_coin-=int(move)
    # Kiểm tra nếu có người nào đó thắng game bằng cách kiểm tra số lượng coin còn lại
    def win(self):
        return self.num_coin<=0
    # Dừng game nếu có ai đã thắng
    def is_over(self):
        return self.win()
    def scoring(self):
        return 100 if self.win() else 0
    # Tạo hàm để xem trạng thái hiện tại của đống coin:
    def show(self):
        print('Số lượng coin còn lại là: ',self.num_coin)
#Tạo hàm main và khởi tạo bảng chuyển vị TT (transposition table). TT được sử dụng trong game để lưu trữ vị trí và bước đi để tăng tốc cho thuật toán
if __name__=="__main__":
    tt=TT()
    #Tạo hàm ttentry để lấy số lượng coin. Đây là một hàm tùy chọn được sử dụng để tạo chuỗi diễn tả tình trạng game
    LastCoinStand.ttentry=lambda self:self.num_coin
    # Giải quyết vấn đề của game này sử dụng AI. hàm id_solve được sử dụng để giải quyết game đã cho bằng cách lặp sâu (iterative deepening). Về cơ bản  thì nó xác định ai là người có thể thắng game sử dụng tất cả các trường hợp
    # Nó tìm kiếm các câu trả lời giống như là: player 1 có thể thắng bằng cách chơi hoàn hảo không ? Máy tính sẽ luôn thua trước đối thủ ?
    # Hàm id_solver khám phá tất cả những lựa chọn khác nhau trong game sử dụng thuật toán Negamax vài lần. Nó luôn luôn bắt đầu tại điểm khởi tạo game và đào sâu liên tục. Nó sẽ làm điều đó cho tới khi điểm số của một người thắng hoặc thua
    # Tham số thứ 2 là một list độ sâu mà nó sẽ đào. Trong trường hợp này tôi chọn giá trị từ 2->20
    result,depth,move=id_solve(LastCoinStand,range(2,20),win_score=100,scoring=None,tt=tt)
    #print(result,depth,move)
    # Bắt đầu game
    # Đây là 2 giá trị player được truyền vào như là tham số players cho class LastCoinStand. AI là user được chọn đi trước nplayer=1
    game=LastCoinStand([AI_Player(tt),Human_Player()])
    game.play()

