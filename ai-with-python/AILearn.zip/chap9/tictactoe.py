from easyAI import TwoPlayersGame,AI_Player,Negamax,SSS
from easyAI.Player import Human_Player
# Tạo class chứa các method thừa kế class TwoPlayerGame và chọn người bắt đầu.
class GameController(TwoPlayersGame):
    def __init__(self,players):
        self.players=players
        self.nplayer=1
        # Chúng ta sử dụng một bảng game 3x3 từ một hàng 9
        self.board=[0]*9
    # Tạo hàm để tính toán tất cả các bước đi có thể:
    def possible_moves(self):
        return [a+1 for a,b in enumerate(self.board) if b==0]
    # Tạo bảng để update lại bảng sau mỗi bước đi
    def make_move(self,move):
        self.board[int(move)-1]=self.nplayer
    # Tạo hàm để xem nếu người nào thua. Chúng ta sẽ kiểm tra xem ai có 3 hàng trước
    def loss_condition(self):
        possible_combinations=[[1,2,3], [4,5,6], [7,8,9],
                               [1,4,7], [2,5,8], [3,6,9],
                               [1,5,9], [3,5,7]]
        return any([all([(self.board[i - 1] == self.nopponent) for i in combination]) for combination in possible_combinations])
    # Kiểm tra xem game kết thúc chưa sử dụng hàm loss_condition
    def is_over(self):
        return (self.possible_moves()==[]) or self.loss_condition()
    #Tạo hàm để hiển thị quá trình xử lý
    def show(self):
        print(self.board)
        print('\n' + '\n'.join([' '.join([['. ', 'O', 'X'][self.board[3 * j + i]] for i in range(3)]) for j in range(3)]))
    #Tính điểm sử dụng hàm loss_condition
    def scoring(self):
        return -100 if self.loss_condition() else 0
# Bắt đầu với hàm main và sử dụng thuật toán để giải quyết vấn đề.
if __name__=="__main__":
    # Thuật toán sử dụng ở đây là Negamax. Chúng ta có thể chỉ định số bước mà thuật toán có thể nghĩ ở đây tôi sử dụng 5
    algorithm=Negamax(5)
    # hoặc thêm thuật toán nữa để cho 2 con AI đối đầu với nhau xem nếu thông minh hơn thì có chiến thắng ?
    # SSS là một thuật toán tìm kiếm không gian trạng thái trên cây với tất cả những nhánh đầu tiên tốt nhất.
    algorithm2=SSS(5)
    # bắt đầu game
    game=GameController([AI_Player(algorithm2),AI_Player(algorithm)])
    game.play()
    if game.loss_condition():
        print("Người thắng: ",game.nopponent)
    else:
        print("Kết quả: Hòa")

