import numpy as np
from easyAI import TwoPlayersGame,  AI_Player, \
        Negamax, SSS

class GameController(TwoPlayersGame):
    def __init__(self, players, board = None):
        # Tạo players
        self.players = players

        # Tạo board
        self.board = board if (board != None) else (
            np.array([[0 for i in range(7)] for j in range(6)]))

        # Thằng nào đi trước tính từ 1 không phải từ 0 như array
        self.nplayer = 1

        # Tạo bảng vị trí
        self.pos_dir = np.array([[[i, 0], [0, 1]] for i in range(6)] +
                   [[[0, i], [1, 0]] for i in range(7)] +
                   [[[i, 0], [1, 1]] for i in range(1, 3)] +
                   [[[0, i], [1, 1]] for i in range(4)] +
                   [[[i, 6], [1, -1]] for i in range(1, 3)] +
                   [[[0, i], [1, -1]] for i in range(3, 7)])

    # Những nước đi có thể
    def possible_moves(self):
        return [i for i in range(7) if (self.board[:, i].min() == 0)]

    # tạo nước đi
    def make_move(self, column):
        line = np.argmin(self.board[:, column] != 0)
        self.board[line, column] = self.nplayer

    # Biểu diễn trạng thái hiện tại
    def show(self):
        print('\n' + '\n'.join(
                ['0 1 2 3 4 5 6', 13 * '-'] +
                [' '.join([['.', 'O', 'X'][self.board[5 - j][i]]
                for i in range(7)]) for j in range(6)]))

    # điều kiện thắng thua
    def loss_condition(self):
        for pos, direction in self.pos_dir:
            streak = 0
            while (0 <= pos[0] <= 5) and (0 <= pos[1] <= 6):
                if self.board[pos[0], pos[1]] == self.nopponent:
                    streak += 1
                    if streak == 4:
                        return True
                else:
                    streak = 0

                pos = pos + direction

        return False

    # Kiểm tra game hết chưa
    def is_over(self):
        return (self.board.min() > 0) or self.loss_condition()

    # Tính điểm
    def scoring(self):
        return -100 if self.loss_condition() else 0

if __name__ == '__main__':
    # Tạo thuật toán Negamax cho thằng đầu tiên để tham số depth là 5 cho nó ngu ngu tí
    algo_neg = Negamax(5)
    # Tạo thuật toán SSS cho thằng thứ 2 nếu để depth càng cao thì thường kết quả sẽ là hòa và nó tính toán khá lâu.
    algo_sss = SSS(5)

    # Start the game
    game = GameController([AI_Player(algo_neg), AI_Player(algo_sss)])
    game.play()

    # In kết quả
    if game.loss_condition():
        print('\nNgười thắng: ', game.nopponent)
    else:
        print("\nKết quả Hòa")

