import numpy as np
import matplotlib.pyplot as plt
from matplotlib import patches

from sklearn import datasets
from sklearn.mixture import GaussianMixture
from sklearn.model_selection import StratifiedKFold

# Lấy bộ dữ liệu iris trong scikit-learn để làm dữ liệu phân tích:
iris=datasets.load_iris()
# Chia dữ liệu thành 2 bộ dữ liệu Training và testing với tỉ lệ 8/2.
#Tham số n_folds là số tập hợp con bạn sẽ có được. Chúng ta gán cho nó giá trị 5 có nghĩa là  bộ dữ liệu sẽ được chia thành 5 phần. Chúng ta sẽ dùng 4 phần để training và một phần còn lại để test:
indices=StratifiedKFold(n_splits=5)
train_index, test_index = next(iter(indices.split(iris.data, iris.target)))
# chia dữ liệu train và test:
X_train,y_train=iris.data[train_index],iris.target[train_index]
X_test,y_test=iris.data[test_index],iris.target[test_index]
# Phân chia số lớp trong dữ liệu train
num_classes=len(np.unique(y_train))
# Xây dựng một bộ phân loại GMM sử dụng những tham số thích hợp
# Tham số n_components là số thành phần trong phân phối cơ bản. Trong trường hợp này nó sẽ là số lớp riêng biệt trong dữ liệu của chúng ta.
# Tham số coveriance_type, Chúng ta cần chỉ rõ kiểu (type) của phương sai. mặc định là 'full'
# Tham số init_params điều khiển số tham số cần đề cập nhật trong suốt quá trình training. chúng ta dùng tham trị là 'wc' (mặc định là kmeans) có nghĩa là trọng số và hiệu phương sai được cập nhật liên tục trong quá trình training
# Tham só max_iter là số lần lặp Expectation_Maximization sẽ thực hiện trong suốt quá trình training
classifier=GaussianMixture(n_components=num_classes,covariance_type='full',max_iter=20)

# Khởi tạo means (trung bình) của classifier:
classifier.means_init=np.array([X_train[y_train==i].mean(axis=0) for i in range(num_classes)])
# Train mô hình GMM sử dụng dữ liệu training

model=classifier.fit(X_train)
# Vẽ biểu đồ bao quanh cho classifier. Chúng ta cần phân chia giá trị vùng (eigenvalues) và vector vùng (eigenvectors) để vẽ hình elip bao quanh những nhóm đó.
plt.figure()
colors='rgb'
markers='ox*'

for i,color in enumerate(colors):
    covariances=classifier.covariances_[i][:2,:2]
    v,w=np.linalg.eig(covariances)
# Normalize eigenvector đầu tiên:
    u=w[0]/np.linalg.norm(w[0])
# Hình elip cần phải xoay chính xác để chỉ ra vùng phân chia : ước tính góc:
    angle=np.arctan2(u[1],u[0])
    angle=180*angle/np.pi
# Phóng to hình eclipse để biểu diễn. số eigenvalues tượng trưng cho cỡ của hình eclipse
    #scaling_factor=8
    #eigenvalues*=scaling_factor
    v = 2. * np.sqrt(2.) * np.sqrt(v)
    # Vẽ hình eclipse

    eclipse=patches.Ellipse(classifier.means_[i,:2],v[0],v[1],180+angle,color=color)
    axis_handle=plt.subplot(1,1,1)
    eclipse.set_clip_box(axis_handle.bbox)
    eclipse.set_alpha(0.6)
    axis_handle.add_artist(eclipse)

    # vẽ dữ liệu input
    curr_data=iris.data[iris.target==i]
    plt.scatter(curr_data[:,0],curr_data[:,1],marker='>',facecolors='c',s=5,label=iris.target_names[i])
    test_data=X_test[y_test==i]
    plt.scatter(test_data[:,0],test_data[:,1],marker=markers[i],facecolors=color,s=50,label=iris.target_names[i])
# Tính toán dự đoán cho dữ liệu train và dữ liệu test
y_train_pred=classifier.predict(X_train)
accuracy_training=np.mean(y_train_pred.ravel()==y_train.ravel())*100
print("Độ chính xác của training data: ",accuracy_training)
y_test_pred=classifier.predict(X_test)
accuracy_test=np.mean(y_test_pred.ravel()==y_test.ravel())*100
print("Độ chính xác của test data: ",accuracy_test)

plt.title(' Phân loại GMM ')
plt.xticks()
plt.yticks()
plt.show()
