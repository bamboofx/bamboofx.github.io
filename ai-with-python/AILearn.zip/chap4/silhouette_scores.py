import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn import metrics

X=np.loadtxt("data/chap4/data_clustering.txt",delimiter=',')
scores=[]
# Khởi tạo giá trị. values array là một danh sách dữ liệu mà chúng ta muốn lặp để tìm số nhóm tối ưu
values=np.arange(2,10)
# Lặp tất cả các giá trị và xây dựng một mô hình KMeans trong mỗi lần lặp:
for num_clusters in values:
    kmeans=KMeans(init='k-means++',n_clusters=num_clusters,n_init=6)
    # Train Kmeans model
    kmeans.fit(X)
    #Ước tính số điểm silhouette cho mô hình bên trên sử dụng phép tính khoảng cách Euclidean
    score=metrics.silhouette_score(X,kmeans.labels_,metric='euclidean',sample_size=len(X))
    print("Số nhóm =",num_clusters)
    print("Điểm silhouette: ",round(score,3))
    scores.append(score)
#Biểu diễn điểm số silhouette cho những giá trị khác nhau
plt.figure()
plt.bar(values,scores,width=0.8,color='blue')
plt.title('Điểm số Silhouette dựa trên số nhóm')
plt.show()
# Lấy Số nhóm tương ứng tốt nhất dựa trên điểm Silhouette
num_clusters=np.argmax(scores)+values[0]
print(" Số nhóm tối ưu nhất: ",num_clusters)
# Train lại dữ liệu với số nhóm tối ưu nhất để vẽ ra màn hình
kmeans.n_clusters=num_clusters
kmeans.fit(X)
# Biểu diễn lại dữ liệu input với số nhóm được chia

#visualize_clusters(X,kmeans.labels_,'Phân nhóm tối ưu dữ liệu Input')
labels=kmeans.labels_
plt.figure()
colors = 'rgbcmykw'
markers = '.,ov^<>12348spP*hH+xXdD|_'
num_clusters = len(np.unique(labels))
markers = markers[0:num_clusters]
colors = colors[0:num_clusters]
for i, marker in zip(range(num_clusters), markers):
    plt.scatter(X[labels == i, 0], X[labels == i, 1], marker=marker, color=colors[i])
x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
# print(x_min,x_max)
y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
plt.title = 'Phân nhóm tối ưu với Silhouette Scores'
plt.xlim(x_min, x_max)
plt.ylim(y_min, y_max)
plt.xticks()
plt.yticks()
plt.show()