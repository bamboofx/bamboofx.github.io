import  numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import MeanShift,estimate_bandwidth

# load dữ liệu làm dữ liệu đầu vào
X=np.loadtxt("data/chap4/data_clustering.txt",delimiter=',')
# Ước tính mật độ của dữ liệu đầu vào ( Bandwidth of input data).
# Tham số bandwidth là tham số cơ sở ước tính mật độ hạt nhân (kernel estimation) được sử dụng bởi thuật toán Mean Shift
# Băng thông ( mật độ ) ảnh hưởng đến tốc độ di chuyển của thuật toán và số lượng nhóm
# vì thế đây làm một tham số quan trọng. Nếu số bandwidth nhỏ, nó sẽ tạo ra kết quả là có quá nhiều nhóm, nếu giá trị của bandwidth lớn thì nó sẽ nhập những nhóm khác biệt vào với nhau
# Tham số quantile ảnh hưởng tới tham số bandwidth, nếu số quantile lớn nó sẽ làm tăng số bandwidth
bandwidth_X=estimate_bandwidth(X,quantile=0.1,n_samples=len(X))
# Train mô hình MeanShift sử dụng số bandwidth bên trên
meanshift_model=MeanShift(bandwidth=bandwidth_X,bin_seeding=True)
meanshift_model.fit(X)
# Tìm những điểm trung tâm của tất cả các nhóm
cluster_centers=meanshift_model.cluster_centers_
print("\n Các điểm trọng tâm: ",cluster_centers)
# Tìm những số của nhóm
labels=meanshift_model.labels_
num_clusters=len(np.unique(labels))
print("\n Số nhóm được phân chia =",num_clusters)
#biểu diễn dữ liệu thành hình ảnh
plt.figure()
markers='o*xvs'

for i,markers in zip(range(num_clusters),markers):
    plt.scatter(X[labels==i,0],X[labels==i,1],marker=markers,color='gray')
    cluster_center=cluster_centers[i]
    plt.plot(cluster_center[0],cluster_center[1],marker='X',markerfacecolor='red',markersize=15)
plt.title('Phân nhóm với Mean Shift')
plt.show()