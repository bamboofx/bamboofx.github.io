import csv
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import MeanShift,estimate_bandwidth
from mpl_toolkits.mplot3d import Axes3D
# Load dữ liệu từ file csv. Chúng ta sử dụng csv reader trong python để đọc dữ liệu từ file và chuyển nó thành numpy array
input_file="data/chap4/sales.csv"
file_reader=csv.reader(open(input_file,'r'),delimiter=',')
X=[]
for count,row in enumerate(file_reader):
    if not count:
        names=row[1:]
        continue
    X.append([float(x) for x in row[1:]])
X=np.array(X)
# Tình băng thông của dữ liệu input
bandwidth=estimate_bandwidth(X,quantile=0.8,n_samples=len(X))
# Train một mô hình mean shift dựa trên số bandwidth
meanshift_model=MeanShift(bandwidth=bandwidth,bin_seeding=True)
meanshift_model.fit(X)
# Tách nhãn và tất cả các điểm trung tâm của nhóm:
labels=meanshift_model.labels_
cluster_centers=meanshift_model.cluster_centers_
num_cluster=len(np.unique(labels))
# In ra terminal các số để kiểm tra
print("Số nhóm của dữ liệu nhập: ",num_cluster)
print("Điểm trung tâm của các nhóm: ")

print('\t'.join([name[:5] for name in names]))
for cluster_center in cluster_centers:
    print("\t".join([str(int(x)) for x in cluster_center]))
# chúng ta làm việc với dữ liệu 6 chiều. Lần lượt hiển thị dữ liệu, chúng ta lấy dữ liệu 2 chiều sử dụng  chiều thứ 2 và thứ 3:
cluster_centers_2d=cluster_centers[:,0:2]
# phác họa các điểm trung tâm của nhóm trên biểu đồ
fig=plt.figure()
ax=fig.add_subplot(111,projection='3d')
x=cluster_centers[:,0]
y=cluster_centers[:,1]
z=cluster_centers[:,2]
c=cluster_centers[:,3]
ax.scatter(x,y,z,c=c,cmap=plt.hot())
#plt.scatter(cluster_centers_2d[:,0],cluster_centers_2d[:,1],s=120,edgecolors='r',facecolors='none')
##offset=0.25
#plt.xlim(cluster_centers_2d[:,0].min() - offset * cluster_centers_2d[:,0].ptp(),
 #        cluster_centers_2d[:,0].max() + offset * cluster_centers_2d[:,0].ptp(),)
#plt.ylim(cluster_centers_2d[:,1].min() - offset * cluster_centers_2d[:,1].ptp(),
 #        cluster_centers_2d[:,1].max() + offset * cluster_centers_2d[:,1].ptp())
#for i,name in enumerate(names):
 #   plt.text(cluster_centers_2d[i,0],cluster_centers_2d[i,1],name)
print(cluster_centers_2d[:,0])
plt.title('các điểm trung tâm')
plt.show()
