import  numpy as np
import matplotlib.pyplot as plt
from  sklearn.cluster import KMeans
from sklearn import metrics

# Load dữ liệu
input_file="data/chap4/data_clustering.txt"
X=np.loadtxt(input_file,delimiter=",")
# Thử biểu diễn dữ liệu input để xem chúng hỗn loạn thế nào
plt.figure()
plt.scatter(X[:,0],X[:,1],marker='o',facecolors='gray',edgecolors='black',s=80)
#print((X[:,0]))
x_min,x_max=X[:,0].min()-1,X[:,0].max()+1
#print(x_min,x_max)
y_min,y_max =X[:,1].min()-1,X[:,1].max()+1
plt.title('Dữ liệu nhập')
plt.xlim(x_min,x_max)
plt.ylim(y_min,y_max)
plt.xticks()
plt.yticks()
plt.show()
# Chạy thử code ở đoạn này bạn sẽ thấy dữ liệu input được phân thành 5 nhóm. Tạo 1 K-Means Object sử dụng các tham số khai báo init,n_clusters,n_init.
# Tham số init đại diện cho phương thức của phép khởi tạo để khởi tạo vị trí trung tâm của trọng tâm, thay vì chọn chúng một cách ngẫu nhiên chúng ta chọn sử dụng 'k-means++' để chọn vị trí trung tâm một cách tốt hơn
# Tham số n_cluslters chỉ số nhóm sẽ tạo
# Tham số n_init chỉ ra số lần thuật toán sẽ chạy trước khi quyết định ra số outcome tốt nhất.
kmeans=KMeans(init='k-means++',n_clusters=5,n_init=10)
# Train K-means với dữ liệu input
model=kmeans.fit(X)
# Để biểu diễn vòng bao quanh dữ liệu chúng ta cần tạo một lưới gồm những điểm và đánh giá mô hình trên những điểm đó,
# Define các bước của grid này:
step_size=0.01
#Chúng ta định nghĩa lưới điểm này và đảm bảo chúng ta đã bọc tất cả những giá trị dữ liệu input

x_vals,y_vals=np.meshgrid(np.arange(x_min,x_max,step_size),np.arange(y_min,y_max,step_size))
# Dự đoán kết quả output cho tất cả các điểm trên lưới sử dụng mô hình K-means đã train;
output=kmeans.predict(np.c_[x_vals.ravel(),y_vals.ravel()])
# Biểu diễn tất cả các giá trị ouput và đổ màu cho mõi nhóm:
output=output.reshape(x_vals.shape)
plt.figure()
plt.clf()
plt.imshow(output,interpolation='nearest',extent=(x_vals.min(),x_vals.max(),y_vals.min(),y_vals.max()),cmap=plt.cm.Paired,aspect='auto',origin='lower')
# Chồng những điểm dữ liệu input lên trên những vùng được tô màu:
plt.scatter(X[:,0],X[:,1],marker='o',facecolors='none',edgecolors='gray',facecolor='gray',s=50)
# Vẽ điểm trọng tâm của nhóm có được sử dụng thuật toán K-means
cluster_centers=kmeans.cluster_centers_
plt.scatter(cluster_centers[:,0],cluster_centers[:,1],marker='X',s=200,edgecolors='red')


plt.title("Vùng bao quanh của nhóm")
plt.xlim(x_min,x_max)
plt.ylim(y_min,y_max)
plt.xticks()
plt.yticks()
plt.show()