import datetime
import warnings
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from mpl_finance import candlestick_ohlc
from hmmlearn.hmm import GaussianHMM
#Load data từ file vì matplotlib đã deprecated nên sử dụng panda để load từ file csv
#lấy file csv từ đây https://github.com/matplotlib/mpl_finance
my_header=['Date','Open','High','Low','Close','Volume']
my_dtypes = {'Date': 'str', 'Open': 'float', 'High': 'float', 'Low': 'float','Close': 'float', 'Volume': 'int'}
my_parse_date=['Date']
data=pd.read_csv('../data/chap11/yahoofinance.csv',index_col=0, parse_dates=True, infer_datetime_format=True)

start="2000-04-04"  #datetime.date(2000,4,4)
end="2002-04-04"    #datetime.date(2004,4,4)
#print(data[(data.index>=start)&(data.index<=end)])
closing_quotes=np.array([quote[1] for quote in data])
print(closing_quotes)