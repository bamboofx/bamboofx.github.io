import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from timeseries_pandas import read_data

# Load cột 3 và cột 4 từ dữ liệu thành 2 biến
x1=read_data('../data/chap11/data_2D.txt',2)
x2=read_data("../data/chap11/data_2D.txt",3)
#Tạo dataframe và đặt tên để tạo dữ liệu 2 chiều dim1,dim2
data=pd.DataFrame({'dim1':x1,'dim2':x2})
# Tách lấy giá trị lớn nhất và nhỏ nhất ở mỗi chiều
print("Giá trị lớn nhất ở mỗi chiều")
print(data.max())
print("Giá trị nhỏ nhất ở mỗi chiều")
print(data.min())
# Tách lấy giá trị trung bình của từng chiều và giá trị trung bình ở 12 hàng đầu tiên
print("Giá trị trung bình của từng chiều")
print(data.mean())
print("Giá trị trung bình giữa 2 chiều theo thời gian")
print(data.mean(1)[:12])
# Vẽ biểu đồ sử dụng cỡ window là 24:
start='1988-2'
end='2006-7'
data[start:end].rolling(center=False,window=24).mean().plot()
plt.title("Giá trị trung bình")
#plt.show()
# Các hệ số tương quan
print("Hệ số tương quan\n",data.corr())
# Vẽ biểu đồ sử dụng window size = 60
plt.figure()
plt.title('Hệ số tương quan')
data[start:end]['dim1'].rolling(window=60).corr(other=data[start:end]['dim2']).plot()
plt.show()

