import matplotlib.pyplot as plt
import pandas as pd
# Sử dụng code bài trước
from timeseries_pandas import read_data
input_file="data/chap11/data_2D.txt"
# Load cột 3 và 4 thành 2 biến khác nhau
x1=read_data(input_file,2)
x2=read_data(input_file,3)
# Tạo 2 khung dữ liệu bằng cách đặt tên cho 2 chiều
data=pd.DataFrame({'dim1':x1,'dim2':x2})
# Vẽ dữ liệu bằng cách chỉ định năm bắt đầu và kết thúc:
start='1968'
end='1975'
data[start:end].plot()
plt.title('Dữ liệu ban đầu')
# Lọc dữ liệu sử dụng điều kiện và vẽ nó ra. Trong trường hợp này chúng ta sẽ lấy dữ liệu ở tất cả các điểm dữ liệu dim1 và nó phải nhỏ hơn 45 và giá trị tại dim2 phải lớn hơn 30:
mdata=data[(data['dim1']<45)&(data['dim2']>30)]
mdata[start:end].plot()
plt.title("dim1<45 & dim2 > 30")
# Chúng ta cũng có thể + 2 series trong Pandas. Hãy thử dim1+dim2 bằng ngày bắt đầu và kết thúc:
plt.figure()
diff=data[start:end]['dim1']+data[start:end]['dim2']
diff.plot()
plt.title("Tổng của dim1 và dim2")
plt.show()