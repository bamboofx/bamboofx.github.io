from pprint import pprint
# Sentence Segmentation
from underthesea import sent_tokenize
from chunks_text import inputTxt
text=inputTxt().split(" \n")
text=(".").join(text)
sent_token=sent_tokenize(text)
print("*"*45,"Sentence token")
pprint(sent_token)
#Word Segmentation
from underthesea import word_tokenize
word_token=word_tokenize(sent_token[0])
print("*"*45,"word_token")
pprint(word_token)
# PosTag
from underthesea import pos_tag
pos_taging=pos_tag(sent_token[0])
print("*"*45,"postag")
pprint(pos_taging)
# Chunking
from underthesea import chunk
textChunk=chunk(sent_token[0])
print("*"*45)
pprint(textChunk)
# Name Entity Recognition
from underthesea import ner
name=ner(sent_token[0])
print("*"*45,"Name Entity")
pprint(name)
# Classify
from underthesea import classify

classifier=classify(sent_token[0])
