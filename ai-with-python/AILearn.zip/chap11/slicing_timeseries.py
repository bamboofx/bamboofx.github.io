import matplotlib.pyplot as plt
# Sử dụng code của bài trước
from timeseries_pandas import read_data

# Load dữ liệu ở cột thứ 3 trong bộ tài liệu 2d
index=2
data=read_data('data/chap11/data_2D.txt',index)
# Tạo năm bắt đầu và kết thúc, sau đó vẽ dữ liệu trong vùng này
start='2003'
end='2011'
plt.figure()
data[start:end].plot()
plt.title("Dữ liệu từ năm "+start+" tới năm "+end)
# Tạo tháng bắt đầu và tháng kết thúc, vẽ dự liệu trong vùng tháng:
start='1988-2'
end='2006-7'
plt.figure()
data[start:end].plot()
plt.title("Dữ liệu từ tháng "+start[-1]+" năm "+start[:-2]+" tới tháng "+end[-1]+" năm "+end[:-2])
plt.show()