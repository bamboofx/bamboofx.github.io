import datetime
import numpy as np
import matplotlib.pyplot as plt
from hmmlearn.hmm import GaussianHMM


#Load Data từ file txt
data=np.loadtxt('../data/chap11/data_1D.txt',delimiter=',')
# Lấy dữ liệu cột thứ 3 để training
X=np.column_stack([data[:,2]])
# Tạo mô hình phân loại HMM với số components=5 và sử dụng hiệp phương sai theo đường chéo
hmm=GaussianHMM(n_components=5,covariance_type='diag',n_iter=1000)
#Train HMM
hmm.fit(X)
# In khoảng cách mean và phương sai (variance) cho mỗi component của mô hình HMM:
print('Means and Variances:')
for i in range(hmm.n_components):
    print('\nHidden State',i+1)
    print('Mean=',round(hmm.means_[i][0],2))
    print('Variance=',round(np.diag(hmm.covars_[i])[0],2))
#Tạo bộ samples 1200 điểm dữ liệu sử dụng mô hình HMM đã tạo và vẽ nó lên đồ thị
num_samples=1200
generated_data, _=hmm.sample(num_samples)
plt.plot(np.arange(num_samples),generated_data[:,0],c='black')
plt.title('Dữ liệu đã tạo')
plt.show()