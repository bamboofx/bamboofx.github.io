import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
# Tạo hàm để đọc dữ liệu nhập. Tham số index là số cột bên trong dữ liệu
def read_data(input_file,index):
    input_data=np.loadtxt(input_file,delimiter=',')
    #Tạo một hàm lambda để chuyển đổi từ string thành format ngày tháng trong Pandas:
    to_date=lambda x,y:str(int(x))+'-'+str(int(y))
    # Sử dụng lambda để lấy ngày bắt đầu từ dòng đầu tiên trong file input
    start=to_date(input_data[0,0],input_data[0,1])
    # Thư viện Pandas cần ngày kết thúc để chọn lọc khi chúng ta thực hiện các phép tính, vì thế chúng ta cần tăng ngày cuối ở dòng cuối cùng bằng một tháng:
    if input_data[-1,1]==12:
        year=input_data[-1,0]+1
        month=1
    else:
        year=input_data[-1,0]
        month=input_data[-1,1]+1
    end=to_date(year,month)
    #Tạo một list các vị trí cùng với ngày tháng dùng ngày bắt đầu và kết thúc và lặp lại trong một tháng:
    date_indices=pd.date_range(start,end,freq='M')
    #Tạo chuỗi dữ liệu liên tục dùng timestamps
    output=pd.Series(input_data[:,index],index=date_indices)
    return output
#Tạo ham main để bắt đầu
if __name__=="__main__":
    input_file='data/chap11/data_2D.txt'
    # Chỉ định số cột có trong dữ liệu
    indices=[2,3]
    #Tạo vòng lặp tất cả các cột và đọc dữ liệu ở mỗi cột
    for index in indices:
        timeseries=read_data(input_file,index)
        #Biểu diễn dữ liệu
        plt.figure()
        timeseries.plot()
        plt.title("Chiều "+str(index-1))
    plt.show()