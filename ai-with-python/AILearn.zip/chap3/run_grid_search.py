import  numpy as np
import  matplotlib.pyplot as plt
from sklearn.metrics import  classification_report
from sklearn import model_selection
from sklearn.model_selection import  GridSearchCV
from sklearn.ensemble import ExtraTreesClassifier
from utilities import visualize_classifier,report_print

# Chúng ta sử dụng dữ liệu tại file data_random_forests.txt
input_file="data/data_random_forests.txt"
data=np.loadtxt(input_file,delimiter=',')
X,y=data[:,:-1],data[:,-1]
#Chia dữ liệu thành các lớp
class_0=np.array(X[y==0])
class_1=np.array(X[y==1])
class_2=np.array(X[y==2])
# chia dữ liệu thành tệp dữ liệu để training và testing
X_train,X_test,y_train,y_test=model_selection.train_test_split(X,y,test_size=0.25,random_state=5)
# Tạo một lưới các tham số mà bạn muốn bộ phân loại kiểm tra. Thường thì chúng ta sẽ giữ một tham số hằng ( parameter constant) và những tham số khác nhau (2 tham số thì giữ nguyên một cái còn cái sau thì đưa ra nhiều trường hợp) . Sau đó chúng ta làm ngược lại để chỉ ra sự kết hợp nào là tốt nhất. Trong trường hợp này chúng ta muốn tìm giá trị tốt nhất cho n_estimators và max_depth
# Định nghĩa một lưới tham số
parameter_grid=[ {'n_estimators': [100], 'max_depth': [2, 4, 7, 12, 16]},{'max_depth': [4], 'n_estimators': [25, 50, 100,250]}]
# giờ thì định nghĩa số liệu của bộ phân loại sẽ dùng để tìm ra tham số kết hợp tốt nhất
metrics = ['precision_weighted', 'recall_weighted']
# Cho mỗi số liệu, chúng ta cần chạy grid-search, Nơi mà chúng ta train bộ phân loại cho một bộ kết hợp các tham số
for metric in metrics:
    print("\n Tìm tham số cho: ",metric)
    classifier=GridSearchCV(ExtraTreesClassifier(random_state=0),parameter_grid,cv=5,scoring=metric)
    classifier.fit(X_train,y_train)
    #print(getattr(classifier, 'cv_results_', None))
    #print(classifier.cv_results_.keys())
    for params in classifier.cv_results_['params']:
        i=classifier.cv_results_['params'].index(params)
        print(params,"---->",round(classifier.cv_results_['mean_test_score'][i],3))
    print("\n Tham số tốt nhất", classifier.best_params_)
    # print terminal cho mỗi tham số kết hợp:

    print("\nĐiểm trên lưới cho tham số trên grid:")
    #in report
    y_pred=classifier.predict(X_test)
    print("\n Báo cáo hiệu suất:\n ")
    print(classification_report(y_test,y_pred))
