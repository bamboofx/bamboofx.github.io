# import package
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report
from sklearn import model_selection
from sklearn.tree import DecisionTreeClassifier
from utilities import visualize_classifier
# Chúng ta xử dụng dữ liệu trong file data_decision_trees.txt . Trong file này dữ liệu ở mỗi dòng được tách bởi dấu [,]. 2 giá trị đầu tiên tương ứng với dữ liệu vào(input data) và giá trị cuối cùng tương ứng là nhãn đích (target label).
input_file="data/data_decision_trees.txt"
data=np.loadtxt(input_file,delimiter=',')
X,y=data[:,:-1],data[:,-1]
# Tách dữ liệu thành 2 lớp dựa trên nhãn của chúng
class_0=np.array(X[y==0])
class_1=np.array(X[y==1])
# Xem thử dữ liệu nhập xử dụng scatter plot của plt:
plt.figure()
plt.scatter(class_0[:,0],class_0[:,1],s=75,facecolors='gray',edgecolors='gray',linewidth=1,marker='x')
plt.scatter(class_1[:, 0], class_1[:, 1], s=75, facecolors='white', edgecolors='black', linewidth=1, marker='o')
plt.title('Dữ liệu nhập')
# Chúng ta cần chia dữ liệu vào trong tập dữ liệu để train và test
X_train,X_test,y_train,y_test = model_selection.train_test_split(X,y,test_size=0.25,random_state=5)
# Tạo xây dựng và biểu diễn phân loại Cây Quyết định  dựa trên tập dữ liệu. tham số random_state chỉ đến số hạt giống được sử dụng bởi những số ngẫu nhiên cần thiết được tạo rađể khởi tạo cho thuật toán phân loại Cây Quyết Định. Tham số max_depth chỉ ra "độ cao" của cây quyết định mà chúng ta muốn xây dựng:
params={'random_state':0,'max_depth' :4}
classifier=DecisionTreeClassifier(**params)
classifier.fit(X_train,y_train)
visualize_classifier(classifier,X_train,y_train,'Tập dữ liệu train')
# tính dữ liệu đầu ra trên phép phân loại dựa trên tập dữ liệu và biểu diễn nó:
y_test_pred=classifier.predict(X_test)
visualize_classifier(classifier,X_test,y_test,"Tập dữ liệu test")
# Đánh giá hiệu suất của phép phân loại bằng cách in báo cáo của phép phân loại
class_names=['Class-0','Class-1']
print("\n"+"#"*40)
print("\n Đánh giá hiệu suất phân loại trên Tập dữ liệu train\n")
print(classification_report(y_train,classifier.predict(X_train),target_names=class_names))
print("#"*40+"\n")
print("#"*40)
print("\n Hiệu suất phân loại trên Tập dữ test\n")
print(classification_report(y_test,y_test_pred,target_names=class_names))
print("#"*40+"\n")
plt.show()
