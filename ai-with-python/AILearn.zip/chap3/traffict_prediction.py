import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import  classification_report,mean_absolute_error
from sklearn import  model_selection,preprocessing
from sklearn.ensemble import ExtraTreesRegressor

# Load data từ file txt
input_file="data/traffic_data.txt"
data=[]
with open(input_file,'r') as f:
    for line in f.readlines():
        items=line[:-1].split(',')
        data.append(items)
data=np.array(data)
# Chúng ta cần mã hóa những features không phải là số trong dữ liệu. Chúng ta cũng cần đảm bảo là chúng ta không mã hóa nhầm số. Mỗi tính năng (features) cần được mã hóa cũng cần phải có một nhãn được mã hóa riêng biệt. Chúng ta cần theo dõi những mã hóa này bởi vì chúng ta sẽ cần chúng khi chúng ta muốn tính toán output cho một điểm dữ liệu không biết.
#Giờ thì tạo một bộ mã hóa nhãn
# Chuyển đổi dữ liệu chữ thành dữ liệu số
label_encoder=[]
X_encoded=np.empty(data.shape)
for i,item in enumerate(data[0]):
    if item.isdigit():
        X_encoded[:,i]=data[:,i]
    else:
        label_encoder.append(preprocessing.LabelEncoder())
        X_encoded[:,i]=label_encoder[-1].fit_transform(data[:,i])
X=X_encoded[:,:-1].astype(int)
y=X_encoded[:,-1].astype(int)
# Chia dữ liệu vào tập training và testing
X_train,X_test,y_train,y_test=model_selection.train_test_split(X,y,test_size=0.25,random_state=5)
# Train một model dùng Extremely Forest
regressor=ExtraTreesRegressor(n_estimators=100,max_depth=4,random_state=0)
model=regressor.fit(X_train,y_train)
# Tinhs toán hiệu suất của mô hình dựa trên dữ liệu test
y_pred=model.predict(X_test)
print("Mean absolute error: ",round(mean_absolute_error(y_test,y_pred),2))
# Bây giờ sẽ xem xét làm sao để tính Output trên một điểm dữ liệu không biết. Chúng ta sẽ sử dụng những bộ mã hóa nhãn để chuyển đổi những tính năng không phải số thành những giá trị số:
test_datapoint=['Tuesday','02:00','San Francisco','no']
test_datapoint_encoded=[-1]*len(test_datapoint)
count=0
for i,item in enumerate(test_datapoint):
    if item.isdigit():
        test_datapoint_encoded[i]=int(test_datapoint[i])
    else:
        test_datapoint_encoded[i]=int(label_encoder[count].transform([test_datapoint[i]]))
        count+=1
test_datapoint_encoded=np.array(test_datapoint_encoded)
# Dự đoán kết quả Output
print("Dự đoán số lượng xe là: ",model.predict([test_datapoint_encoded])[0])