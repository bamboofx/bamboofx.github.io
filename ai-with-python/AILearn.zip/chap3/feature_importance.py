import numpy as np
import  matplotlib.pyplot as plt
from sklearn.ensemble import AdaBoostClassifier
from  sklearn.tree import  DecisionTreeRegressor

from sklearn import datasets
from sklearn.metrics import  mean_squared_error,explained_variance_score
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
from sklearn.svm import SVC
# Đầu tiên ta sử dụng data có sẵn trong scikit-learn:
data=datasets.load_diabetes()
# Xáo trộn dataset để không làm phân tích của chúng ta bị giống nhau
X,y=data['data'],data['target']
    #shuffle(iris.data,iris.target,random_state=7)
#shuffle(data[:,:-1],data[:,-1],random_state=7) #
print(data.feature_names)
print("*"*40)
#print(y)
# Chia dữ liệu để train và test
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2)
# Định nghĩa và train AdaBoost sử dụng Decision Tree regressor như là một mô hình riêng
svc=SVC(probability=True,kernel='linear')
DTR=DecisionTreeRegressor(max_depth=4)
regressor=AdaBoostClassifier(base_estimator=None,algorithm="SAMME",n_estimators=50,learning_rate=2)
model=regressor.fit(X_train,y_train)
# Ước tính hiệu suất của phép hồi quy (regressor):
y_pred=model.predict(X_test)
mse=mean_squared_error(y_test,y_pred)
evs=explained_variance_score(y_test,y_pred)
print("\nAdaptiveBoost REGRESSOR")
print("\nMean square error",round(mse,2))
print("\nVariance Score: ",round(evs,2))
# Phép hồi quy này có một phương thức có sẵn có thể gọi để tính độ quan trọng tính năng tương đối:
feature_importances=regressor.feature_importances_
feature_name=data.feature_names
# Đơn giản hóa giá trị của độ quan trọng tính năng tương đối:
feature_importances=100.0*(feature_importances/max(feature_importances))
# Sắp xếp feature lại (sort) để có thể phác họa thành đồ thị:
index_sorted=np.flipud(np.argsort(feature_importances))
# Sắp xếp điểm trên trục X để làm đồ thị dạng biểu đồ
pos=np.arange(index_sorted.shape[0])+1
# vẽ biểu đồ với plot
plt.figure()
plt.bar(pos,feature_importances[index_sorted],align='center')
plt.xticks(pos,np.array(feature_name)[index_sorted])
plt.ylabel('Độ quan trọng tương đối')
plt.title("Độ quan trọng của tính năng sử dụng AdaBoost")
plt.show()