# import package cần thiết
import sys
import  numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import  ExtraTreesClassifier
from sklearn import model_selection
from  sklearn.metrics import classification_report
from  utilities import visualize_classifier
from  utilities import report_print
# Chúng ta sẽ sử dụng dữ liệu trong file data/data_imbalance.txt để làm dữ liệu phân tích. Tải dữ liệu. mỗi dòng trong file các giá trị được tách với nhau bởi dấu phẩy. Hai giá trị đầu tiên đối xứng nhau là giá trị đầu vào, và giá trị cuối cùng đại diện cho nhãn đích. Chúng ta có 2 lớp trong bộ dữ liệu(dataset)
input_file="data/data_imbalance.txt"
data=np.loadtxt(input_file,delimiter=',')
X,y=data[:,:-1],data[:,-1]
# Chia dữ liệu nhập vào 2 lớp dựa trên nhãn của nó

class_0=np.array(X[y==0])
class_1=np.array(X[y==1])
# Biểu diễn dữ liệu nhập lên màn hình sử dụng scatter trong plot:
plt.figure()

plt.scatter(class_0[:,0],class_0[:,1],s=75,facecolors='black',edgecolors='black',linewidths=1,marker="x")
plt.scatter(class_1[:,0],class_1[:,1],s=75,facecolors='gray',edgecolors='black',linewidths=1,marker="o")
plt.title("Dữ liệu nhập")

# Chia dữ liệu để tạo bộ dữ liệu train và testing
X_train,X_test,y_train,y_test=model_selection.train_test_split(X,y,test_size=0.25,random_state=5)
#Tiếp theo chúng ta cần định nghĩa tham số cho bộ phân loại Extremely Random Forest.
# Chú ý ở đây là một tham số đầu vào được gọi là balance tham số này điều khiển việc chúng ta có muốn hoặc không muốn sử dụng thuật toán tính toán cho lớp cân băng.
# Nếu có chúng ta cần thêm một tham số được gọi là  class_weight tham số này nói cho lớp phân loại biết nó cần cân bằng với tham số này, vậy nó tỷ lệ với số điểm dữ liệu ở mỗi lớp:
# tham số cho ERF
params={'n_estimators':100,'max_depth':4,'random_state':0}
if len(sys.argv)>1:
    if sys.argv[1]=='balance':
        params={'n_estimators':100,'max_depth':4,'random_state':0,'class_weight':'balanced'}
    else:
        raise TypeError("Invalid input argument; Thêm balance vào argument đi pa")
# Xây dựng, fit để luyện và biểu diễn lớp phân loại sử dụng dữ liệu training:
classifier=ExtraTreesClassifier(**params)
classifier.fit(X_train,y_train)
visualize_classifier(classifier,X_train,y_train,'Dữ liệu training')
# Predict dầu ra - dự đoán đầu ra và biểu diễn dữ liệu đầu ra:
y_test_pred=classifier.predict(X_test)
visualize_classifier(classifier,X_test,y_test,'Dữ liệu test')

report_print(classifier,['Class-0','Class-1'],X_train,y_train,y_test,y_test_pred)
