import argparse

import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report
from sklearn import model_selection
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from utilities import visualize_classifier

# Định nghĩa một đối số phân tích cho Python để chúng ta có thể lấy kiểu phân loại như là một tham số đầu vào. Dựa trên tham số này chúng ta có thể xây dựng một bộ phân loại Random Forest hoặc một bộ phân loại Extremely Random Forests
def build_arg_parser():
    parser=argparse.ArgumentParser(description='Classify data using Enxemble Learning Techniques')
    parser.add_argument('--classifier-type',dest='classifier_type',required=True,choices=['rf','erf'],help="Type of classifier to use can be either 'rf' or 'erf'")
    return parser
# Định nghĩa hàm Main và parser tham số đầu vào
if __name__=='__main__':
    # Parser tham số đầu vào
    args=build_arg_parser().parse_args()
    classifier_type=args.classifier_type
# Chúng ta sẽ xử dụng dữ liệu từ file data/data_random_forest.txt. Mỗi dòng trong file này sẽ có một dấu phẩy để phân chia các giá trị. Hai giá trị đầu tiên tương ứng là giá trị đầu vào ,và giá trị cưới cùng tương ứng là nhãn đích. Chúng ta có 3 lớp khác biệt trong tập dũ liệu này.
# Load input data
input_file='data/data_random_forests.txt'
data=np.loadtxt(input_file,delimiter=",")
X,y=data[:,:-1],data[:,-1]
# Tách dữ liệu đầu vào thành 3 lớp
class_0=np.array(X[y==0])
class_1=np.array(X[y==1])
class_2=np.array(X[y==2])
# In dữ liệu đầu vào lên biểu đồ
plt.figure()
plt.scatter(class_0[:,0],class_0[:,1],s=75,facecolors="white",edgecolors="black",linewidths=1,marker='s')
plt.scatter(class_1[:,0],class_1[:,1],s=75,facecolors="black",edgecolors="black",linewidths=1,marker='o')
plt.scatter(class_2[:,0],class_2[:,1],s=75,facecolors="gray",edgecolors="black",linewidths=1,marker='^')
plt.title(" Dữ liệu đầu vào ")

# Chia dữ liệu vào trong tập training và testing (split the data into training and testing datasets):
X_train,X_test,y_train,y_test=model_selection.train_test_split(X,y,test_size=0.25,random_state=5)
#Định nghĩa tham số để sử dụng khi chúng ta xây dựng bộ phân loại. tham số n_estimators chỉ ra số cây (trees) chúng ta sẽ xây dựng, và tham số max_depth là số bậc (level) trên mỗi cây. Tham số random_state là số hạt giống (seed) của số ngẫu nhiên cần thiết để khởi tạo một thuật toán phân loại Random Forest
# Ensemble Learning classifier
params={'n_estimators':100,'max_depth':4,'random_state':0}
#Dựa trên tham số đầu vào, chúng ta cũng xây dựng một Bộ phân loại Random Forests hoặc một Extremely Random Forest classifier
if classifier_type=='rf':
    classifier=RandomForestClassifier(**params)
else:
    classifier=ExtraTreesClassifier(**params)
# Train và hiển thị bộ phân loại ra màn hình:
classifier.fit(X_train,y_train)
#visualize_classifier(classifier,X_train,y_train,"Bộ dữ liệu training(training dataset)")
# Tính toán (dự đoán) kết quả đầu ra dựa trên bộ dữ liệu test và hiển thị ra màn hình:
y_test_pred=classifier.predict(X_test)
#visualize_classifier(classifier,X_test,y_test,"Bộ dữ liệu testing(testing dataset)")
# Đánh giá hiệu suất của phép phân loại bằng cách print report
class_names=['Class-0','Class-1','Class-2']
print("\n","#"*44)
print("\n Hiệu suất phân loại trên dữ liệu training (training dataset)")
print(classification_report(y_train,classifier.predict(X_train),target_names=class_names))
print("#"*44,"\n")

print("\n","*"*44)
print("\n Hiệu suất phân loại trên dữ liệu testing(testing dataset)")
print(classification_report(y_test,y_test_pred,target_names=class_names))
print("*"*40)

# Tính toán độ tin cậy của một mô hình
test_datapoints=np.array([[5,5],[3,6],[6,4],[7,2],[4,4],[5,2]])
# Object classifier  là một phương thức được xây dựng sẵn để tính toán độ tin cậy. Hãy phân loại mỗi điểm và tính toán giá trị độ tin cậy:
print("\n Thước đo độ tin cậy")
for datapoint in test_datapoints:
    probabilities=classifier.predict_proba([datapoint])[0]
    print("\nProbabilities: ",probabilities)
    predicted_class='Class-'+str(np.argmax(probabilities))
    print('\nDataPoint:',datapoint)
    print('Predict Class:',predicted_class)
# In ra màn hình
visualize_classifier(classifier,test_datapoints,[0]*len(test_datapoints),"Kiểm tra điểm dữ liệu(Test datapoints)")

