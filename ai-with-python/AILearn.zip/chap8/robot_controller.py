import copy
import random
from functools import partial
import numpy as np
from deap import algorithms,base,creator,tools,gp

#Tạo class robot
class RobotController(object):
    def __init__(self,max_moves):
        self.max_move=max_moves
        self.moves=0
        self.consumed=0
        self.routine=None
        # Định nghĩa các hướng đi và cách di chuyển
        self.direction=["north","east","south","west"]
        self.direction_row=[1,0,-1,0]
        self.direction_col=[0,1,0,-1]
    #Tạo hàm reset
    def _reset(self):
        self.row=self.rowStart
        self.col=self.colStart
        self.direction=1
        self.moves=0
        self.consumed=0
        self.matrix_exc=copy.deepcopy(self.matrix)
    # Tạo hàm xác định các toán tử điều kiện
    def _conditional(self,condition,out1,out2):
        out1() if condition() else out2()
    # Rẽ trái
    def turn_left(self):
        if self.moves<self.max_move:
            self.moves+=1
            self.direction=(self.direction-1)%4
    # Rẽ phải
    def turn_right(self):
        if self.moves<self.max_move:
            self.moves+=1
            self.direction=(self.direction+1)%4
    # Đi thẳng
    def move_forward(self):
        if self.moves<self.max_move:
            self.moves+=1
            self.row=(self.row+self.direction_row[self.direction])%self.matrix_row
            self.col=(self.col+self.direction_col[self.direction])%self.matrix_col
            if self.matrix_exc[self.row][self.col]=="target":
                self.consumed+=1
            self.matrix_exc[self.row][self.col]="passed"
    # Tạo hàm để định vị mục tiêu. Nếu nó nhìn thấy mục tiêu phía trước thì sẽ cập nhật matrix phù hợp
    def sense_target(self):
        ahead_row=(self.row+self.direction_row[self.direction])%self.matrix_row
        ahead_col=(self.col+self.direction_col[self.direction])%self.matrix_col
        return self.matrix_exc[ahead_row][ahead_col]=="target"
    # Khi nhìn thấy mục tiêu phía trước thì tạo hàm phù hợp và trả về :
    def if_target_ahead(self,out1,out2):
        return partial(self._conditional,self.sense_target,out1,out2)
    # tạo hàm run
    def run(self,routine):
        self._reset()
        while self.moves<self.max_move:
            routine()
    # Tạo hàm để đi khắp bản đổ . Biểu tượng # tượng trưng cho tất cả các mục tiêu trên bản đồ. và biểu tượng S là điểm bắt đầu. còn lại biểu thị các ô trống
    def traverse_map(self,matrix):
        self.matrix=list()
        for i,line in enumerate(matrix):
            self.matrix.append(list())
            for j,col in enumerate(line):
                if col=="#":
                    self.matrix[-1].append("target")
                elif col==".":
                    self.matrix[-1].append("empty")
                elif col=="S":
                    self.matrix[-1].append("empty")
                    self.rowStart=self.row=i
                    self.colStart=self.col=j
                    self.direction=1
        self.matrix_row=len(self.matrix)
        self.matrix_col=len(self.matrix[0])
        self.matrix_exc=copy.deepcopy(self.matrix)
# Tạo class để tạo hàm dựa trên những tham số input
class Prog(object):
    def _progn(self,*args):
        for arg in args:
            arg()
    def prog2(self,out1,out2):
        return  partial(self._progn,out1,out2)
    def prog3(self,out1,out2,out3):
        return partial(self._progn,out1,out2,out3)
    # Tạo hàm đánh giá
def eval_func(individual):
    global robot,pset
    # biến đổi từ biểu thức thành hàm Python
    routine=gp.compile(individual,pset)
    # Chạy chương trình:
    robot.run(routine)
    return robot.consumed,
#Tạo toolbox:
def create_toolbox():
    global robot,pset
    pset = gp.PrimitiveSet("MAIN", 0)
    pset.addPrimitive(robot.if_target_ahead, 2)
    pset.addPrimitive(Prog().prog2, 2)
    pset.addPrimitive(Prog().prog3, 3)
    pset.addTerminal(robot.move_forward)
    pset.addTerminal(robot.turn_left)
    pset.addTerminal(robot.turn_right)

    creator.create("FitnessMax", base.Fitness, weights=(1.0,))
    creator.create("Individual", gp.PrimitiveTree, fitness=creator.FitnessMax)

    #Tạo hàm fitness:
    toolbox = base.Toolbox()

    # Attribute generator
    toolbox.register("expr_init", gp.genFull, pset=pset, min_=1, max_=2)

    # Structure initializers
    toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.expr_init)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)

    toolbox.register("evaluate", eval_func)
    toolbox.register("select", tools.selTournament, tournsize=7)
    toolbox.register("mate", gp.cxOnePoint)
    toolbox.register("expr_mut", gp.genFull, min_=0, max_=2)
    toolbox.register("mutate", gp.mutUniform, expr=toolbox.expr_mut, pset=pset)
    return toolbox
# Tạo hàm main
if __name__=="__main__":
    global robot
    random.seed(7)
    max_move=750
    robot=RobotController(max_move)
    toolbox=create_toolbox()
    # Đọc Map
    with open('data/chap8/target_map.txt','r') as f:
        robot.traverse_map(f)
    # Tạo một quần thể 400 cá nhân và tạo hall_of_fame cho những thằng còn sống
    population=toolbox.population(n=400)
    hall_of_fame=tools.HallOfFame(1)
    # Đăng ký các thông số dữ liệu và chạy thuật toán tiến hóa sử dụng các tham số
    stats = tools.Statistics(lambda x: x.fitness.values)
    stats.register("avg", np.mean)
    stats.register("std", np.std)
    stats.register("min", np.min)
    stats.register("max", np.max)
    probab_crossover = 0.4
    probab_mutate = 0.3
    num_generations = 50
    algorithms.eaSimple(population, toolbox, probab_crossover,probab_mutate, num_generations, stats, halloffame=hall_of_fame)