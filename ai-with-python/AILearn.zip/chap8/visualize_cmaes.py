import numpy as np
import matplotlib.pyplot as plt
from deap import algorithms,base,benchmarks,cma,creator,tools
# Tạo toolbox
def create_toolbox(strategy):
    creator.create("FitnessMin",base.Fitness,weights=(-1,))
    creator.create("Individual",list,fitness=creator.FitnessMin)
    toolbox=base.Toolbox()
    toolbox.register("evaluate",benchmarks.rastrigin)
    np.random.seed(7)
    # Tạo method generate và update. Điều này có liên quan đến bản cập nhật mô hình nơi chúng ta sẽ tạo một quần thể từ một strategy và stategy này cập nhật dựa trên quần thể
    toolbox.register("generate",strategy.generate,creator.Individual)
    toolbox.register("update",strategy.update)
    return toolbox
#Tạo hàm main.
if __name__=="__main__":
    #Tạo số cá thể và số lần tiến hóa (thế hệ)
    num_individuals=10
    num_generations=125
    #Chúng ta cần định nghĩa hàm strategy trước khi chúng ta bắt đầu
    strategy=cma.Strategy(centroid=[5.0]*num_individuals,sigma=5.0,lambda_=20*num_individuals)
    toolbox=create_toolbox(strategy)
    # Tạo một object HallOfFame. object này chứa những cá nhân tốt nhất được chọn trong quần thể. object này được giữ ở một định dạng được sắp xếp suốt quá trình.
    # Bằng cách này thành phần đầu tiên trong object HallOfFame là cá thể có giá trị thích nghi (fitness) tốt nhất trong quá trình tiến hóa
    hall_of_fame=tools.HallOfFame(1)
    # Tạo các số liệu thống kê sử dụng hàm Statistics trong tools
    stats=tools.Statistics(lambda x:x.fitness.values)
    stats.register("avg",np.mean)
    stats.register("std",np.std)
    stats.register("min",np.min)
    stats.register("max",np.max)
    # tạo object logbook để theo dõi quá trình tiến hóa. Nó về cơ bản là một list của dictionaries:
    logbook=tools.Logbook()
    logbook.header="gen","eval","std","min","avg","mã"
    # Tạo object để kết hợp tất cả các dữ liệu:
    sigma=np.ndarray((num_generations,1))
    axis_ratio=np.ndarray((num_generations,1))
    diagD=np.ndarray((num_generations,num_individuals))
    fbest=np.ndarray((num_generations,1))
    best=np.ndarray((num_generations,num_individuals))
    std=np.ndarray((num_generations,num_individuals))
    # lặp để tạo quá trình tiến hóa
    for gen in range(num_generations):
        population=toolbox.generate()
        # Tìm cá nhân thích hợp sử dụng hàm thích nghi:
        fitnesses=toolbox.map(toolbox.evaluate,population)
        for ind,fit in zip(population,fitnesses):
            ind.fitness.values=fit
        # Cập nhật stategy dựa trên quần thể
        toolbox.update(population)
        # Cập nhật hallofFame và số liệu sử dụng thế hệ hiện tại của các cá thể:
        hall_of_fame.update(population)
        record=stats.compile(population)
        logbook.record(evals=len(population),gen=gen,**record)
        print(logbook.stream)
        # Save dữ liệu để vẽ biểu đồ
        sigma[gen]=strategy.sigma
        axis_ratio[gen]=max(strategy.diagD)**2/min(strategy.diagD)**2
        diagD[gen,:num_individuals]=strategy.diagD**2
        fbest[gen]=hall_of_fame[0].fitness.values
        best[gen,:num_individuals]=hall_of_fame[0]
        std[gen,:num_individuals]=np.std(population,axis=0)
    # Đinh nghĩa trục x để vẽ số liệu thống kê
    x=list(range(0,strategy.lambda_*num_generations,strategy.lambda_))
    avg,max_,min_=logbook.select("avg","max","min")
    plt.figure()
    plt.semilogx(x,avg,"--b",label="avg")
    plt.semilogx(x, max_, "--b",label="max")
    plt.semilogx(x, min_, "--b",label="min")
    plt.semilogx(x, fbest, "--c",label="fbest")
    plt.semilogx(x, sigma, "--g",label="sigma")
    plt.semilogx(x, axis_ratio, "--r",label="axis_ratio")
    plt.grid(True)
    plt.legend()

    plt.figure()
    plt.plot(x,best)
    plt.grid(True)

    plt.title("Object Variables")

    plt.figure()
    plt.semilogy(x,diagD)
    plt.grid(True)
    plt.title("Scaling (All Main Axes)")

    plt.figure()
    plt.semilogy(x,std)
    plt.grid(True)
    plt.title("Standard Deviations (độ lệch chuẩn) in all cột")
    plt.show()

