import operator
import math
import random
import numpy as np
from deap import algorithms,base,creator,tools,gp

#Tạo toolBox
# Để tạo toolbox ở đây chúng ta cần tạo một bộ sơ khai (primitives)
# Bộ sơ khai này là những phép toán cơ bản sẽ dược sử dụng trong suốt quá trình phát triển.
# Chúng phục vụ việc xây dựng các khối cho các cá thể.
# Chúng ta sẽ sử dụng các hàm số học cơ bản cho bộ sơ khai này
def create_toolbox():
    pset=gp.PrimitiveSet("MAIN",1)
    pset.addPrimitive(operator.add,2)
    pset.addPrimitive(operator.sub,2)
    pset.addPrimitive(operator.mul,2)
    pset.addPrimitive(division_operator,2)
    pset.addPrimitive(operator.neg,1)
    pset.addPrimitive(math.cos,1)
    pset.addPrimitive(math.sin,1)
    # Giờ chúng ta cần tạo hằng số phù du ( ephemeral constant).
    # Nó là một giá trị đầu cuối đặc biệt không có giá trị đặc biệt. Khi một trương trình nối thêm hằng số phù du như vậy vào cây(tree), thì hàm đó sẽ được thực thi. Kết quả được thêm vào caay như là một số không đổi.
    # Những số không đổi này có thể lấy giá trị là -1,0,1
    pset.addEphemeralConstant("rand1",lambda :random.randint(-1,1))
    #Tên mặc định của đối số là ARGx. Giờ thì đổi tên nó thành x. Không cần thiết phải làm điều này nhưng lại hưu dụng để quản lý:
    pset.renameArguments(ARG0='x')
    #chúng ta cần 2 dạng object là fitness(thích nghi) và cá thể (individual). giờ thì sử dụng creator để tạo
    creator.create("FitnessMin",base.Fitness,weights=(-1.0,))
    creator.create("Individual",gp.PrimitiveTree,fitness=creator.FitnessMin)
    # Tạo toolbox và các hàm cần đăng ký để sử dụng. Quá trình đăng ký giống ở phần trước
    tool_box=base.Toolbox()
    tool_box.register("expr", gp.genHalfAndHalf, pset=pset, min_=1, max_=2)
    tool_box.register("individual", tools.initIterate, creator.Individual, tool_box.expr)
    tool_box.register("population", tools.initRepeat, list, tool_box.individual)
    tool_box.register("compile",gp.compile,pset=pset)
    tool_box.register("evaluate",eval_func,points=[x/10. for x in range(-10,10)])
    tool_box.register("select",tools.selTournament,tournsize=3)
    tool_box.register("mate",gp.cxOnePoint)
    tool_box.register("expr_mut",gp.genFull,min_=0,max_=2)
    tool_box.register("mutate",gp.mutUniform,expr=tool_box.expr_mut,pset=pset)
    tool_box.decorate("mate",gp.staticLimit(key=operator.attrgetter("height"),max_value=17))
    tool_box.decorate("mutate", gp.staticLimit(key=operator.attrgetter("height"), max_value=17))
    return tool_box


#Tạo một hàm phép chia để quản lý vấn đề gặp lỗi khi chia cho 0
#numerator :  tử số, denominator mẫu ssoos)
def division_operator(numerator,denominator):
    if denominator==0:return 1
    return numerator/denominator
#Tạo hàm đánh giá sẽ được sử dụng để tính toán. Chúng ta cần tạo một hàm có thể gọi để tính toán cá thể được input
def eval_func(individual,points):
    # Chuyển đổi từ cây biểu thành hàm
    func=tool_box.compile(expr=individual)
    # Tính số mean squared error(mse) giữa các hàm đã định nghĩa phía trên và biểu thức gốc
    mse=((func(x)-(2*x**3-3*x**2-4*x+1))**2 for x in points)
    return math.fsum(mse)/len(points),

#Tạo hàm main
if __name__=="__main__":
    random.seed(7)
    tool_box=create_toolbox()
    #Tạo quần thể sử dụng hàm sẵn có trong toolbox chúng ta đã tạo.
    # chúng ta sẽ sử dụng 450 cá thể. Người dùng tạo ra số này vì thế chúng ta nên  thử thí nghiệm với nó.
    population=tool_box.population(n=450)
    # Tạo object hall_of_fame
    # Object hall of fame là những cá thể còn sống tốt nhất sau 1 quá trình chọn lọc
    hall_of_fame=tools.HallOfFame(1)
    #Số liệu thống kê luôn là điều quan trọng khi chúng ta xây dựng thuật toán di truyền
    stats_fit=tools.Statistics(lambda x:x.fitness.values)
    stats_size=tools.Statistics(len)
    # Đăng ký số liệu thống kê
    mstats=tools.MultiStatistics(fitness=stats_fit,size=stats_size)
    mstats.register("avg",np.mean)
    mstats.register("std", np.std)
    mstats.register("min", np.min)
    mstats.register("max", np.max)
    # Tạo các xác xuất trao đổi chéo, đột biến và số thế hệ được tạo ra
    probab_crossover=0.4
    probab_mutate=0.2
    num_generations=60
    # Chạy thuật toán tiến hóa sử dụng các tham số bên trên
    population,log=algorithms.eaSimple(population,tool_box,probab_crossover,probab_mutate,num_generations,stats=mstats,halloffame=hall_of_fame,verbose=True)
