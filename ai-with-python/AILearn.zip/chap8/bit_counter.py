import random
from deap import base,creator,tools
# Giờ chúng ta muốn tạo một chuỗi bít với độ dài là 75 và chúng ta muốn nó chứa 45 số 1.
#Chúng ta cần tạo một hàm đánh giá (evaluation function) để có thể sử dụng như là mục tiêu cần đạt :
def eval_func(individual):
    target_sum=45
    return len(individual)-abs(sum(individual)-target_sum),
# Nếu bạn nhìn vào công thức được sử dụng ở hàm trên bạn có thể thấy nó sẽ đạt giá trị lớn nhất khi số lượng số 1 bằng 45. độ dài các cá thể là 75. Khi những số 1 của nó bằng 45 thì giá trị trả về phải là 75
#Giờ chúng ta tạo một hàm để tạo toolbox. Hãy tạo một object creator để làm hàm thích nghi và theo dõi các cá thể. Class  Fitness được dùng ở đây là một abtract class và no dung tham số weights.
# Chúng ta sẽ xây dựng một thích nghi tối đa sử dụng số weights dương:
def create_toolbox(num_bits):
    creator.create("FitnessMax",base.Fitness,weights=(1.0,))
    creator.create("Individual",list,fitness=creator.FitnessMax)
    # Dòng đầu tiên tạo ra một object thích nghi tối đa và đặt tên nó là FitnessMax. Dòng thứ 2 tạo ra cá thể. Trong phần sử lý này thì cá thể đầu tiên được tạo ra là một list các số float
    # Để sản xuất ra cá thể này, chúng ta phải tạo một Individual class sử dụng creator. Tham số fitnesss sử dụng object FitnessMax đã tạo ra trước đó.
    #Một toolbox là một object thường dùng trong DEAP. Nó dùng để chứa các hàm cùng với các tham số.
    toolbox=base.Toolbox()
    # Chúng ta bắt đầu đăng ký các hàm khác nhau vào trong object toolbox này. Bắt đầu với việc tạo ra các số nguyên ngẫu nhiên 0 và 1. Đây là cách cơ bản để tạo ra chuỗi bit
    toolbox.register("attr_tool",random.randint,0,1)
    # Giờ thì đăng ký hàm individual. Method initRepeat gồm có 3 tham số.
    # * container class cho các individual (cá thể)
    # * hàm dùng để fill cái container trên
    # * Thời dian chúng ta muốn lặp cái hàm này lại
    toolbox.register("individual",tools.initRepeat,creator.Individual,toolbox.attr_tool,num_bits)
    # Chúng ta cần tạo một hàm quần thể (population). Chúng ta muốn quần thể này là một list gồm các cá thể (individual)
    toolbox.register("population",tools.initRepeat,list,toolbox.individual)
    # Giờ chúng ta tạo ra các phép toán. Đăng ký các hàm đánh giá mà chúng ta đã tạo ra ở bên trên, nó sẽ thực hiện như một hàm thích nghi. Chúng ta muốn các cá thể là một chuỗi bit có 45 số 1
    toolbox.register("evaluate",eval_func)
    # Tạo phép toán trao đỏi chéo và đặt tên nó là mate sử dụng Method cxTwoPoint của tools
    toolbox.register("mate",tools.cxTwoPoint)
    # Tạo phép toán đột biến đặt tên nó là mutate sử dụng method mutFlipBit. chúng ta cần chỉ định xác suất đột biến cho từng thuộc tính bằng tham trị indpb
    toolbox.register("mutate",tools.mutFlipBit,indpb=0.05)
    # Tạo một hàm sử dụng method selTournament. Nó sẽ chỉ định cá thể nào sẽ được chọn để "chăn" tiếp ( phép chọn - selection)
    # * tournsize: số các cá thể sẽ tham gia mỗi Tournament ( trận đấu giữa các cá thể ) who is the survival
    toolbox.register("select",tools.selTournament,tournsize=3)
    return  toolbox
# Đây là việc cơ bản để thực hiện tất cả các khái niệm chúng ta đã thảo luận ở phần trước. Một hàm tạo toolbox rất phổ biến trong DEAP và chúng ta sẽ sử dụng nó trong suốt chương 8 này.
# Vì vậy sẽ rất quan trọng để dành một chút thời gian để hiểu cách chúng ta tạo ra cái toolbox này thế nào

# Tạo hàm main và tạo độ dài chuỗi bit:
if __name__=="__main__":
    num_bits=75
    #Tạo toolbox với numbits
    toolbox=create_toolbox(num_bits)
    # đặt số ngẫu nhiên cho random = 7
    random.seed(7)
    #Tạo một quần thể 500 thanh niên (individual)
    population=toolbox.population(n=500)
    # Tạo số xác suất cho biến dổi chéo (crossover) và đột biến (mutate). Bạn có thể thay đổi các số này để xem nó ảnh hưởng thế nào đến kết quả:
    probabilities_cross,prob_mutate=0.8,0.2
    # Tạo số lượng thế hệ mà chúng ta cần lặp cho đến khi quá trình xử lý dừng. Nếu tăng số thế hệ được tạo bạn sẽ đưa cho thuật toán tăng thêm sức mạnh cho quần thể
    num_generations=60
    # Đánh giá tất cả các cá thể trong quần thể sử dụng hàm đánh giá
    print("Bắt đầu quá trình tiến hóa")
    #Đánh giá cá thể
    fitnesses=list(map(toolbox.evaluate,population))

    for ind,fit in zip(population,fitnesses):
        ind.fitness.values=fit
    # Bắt đầu vòng lặp các thế hệ
    print('\n Đánh giá xong:',len(population),'cá thể')
    for g in range(num_generations):
        print("\n==== Thế hệ",g)
        offspring=toolbox.select(population,len(population))
        # Sao chép các cá thể được chọn
        offspring=list(map(toolbox.clone,offspring))
        # Áp dụng trao đổi chéo và đột biến và thế hệ tiếp theo của các cá thể sử dụng số xác suất tro trước. Sau mỗi lần chúng ta cần reset lại số thích nghi (fitness)
        for child1,child2 in zip(offspring[::2],offspring[1::2]):
            if random.random()<probabilities_cross:
                toolbox.mate(child1,child2)
                # xóa số thích nghi của child
                del child1.fitness.values
                del child2.fitness.values
        for mutant in offspring:
            if random.random()<prob_mutate:
                toolbox.mutate(mutant)
                del mutant.fitness.values
        # Đánh giá cá nhân cần phải loại bỏ
        invalid_individuals=[ind for ind in offspring if not ind.fitness.valid]
        fitness=map(toolbox.evaluate,invalid_individuals)
        for ind,fit in zip(invalid_individuals,fitness):
            ind.fitness.values=fit
        print("Đánh giá :", len(invalid_individuals),"cá thể")
        # Thay đổi quần thể bằng thế hệ mới của các cá thể
        population[:]=offspring
        # In trạng thái của thế hệ hiện tại để xem quá trình xử lý:
        fits=[ind.fitness.values[0] for ind in population]
        length=len(population)
        mean=sum(fits)/length
        sum2=sum(x*x for x in fits)
        std=abs(sum2/length-mean**2)**0.5
        print('Min =',min(fits),', Max =',max(fits))
        print('Average =',round(mean,2),', Standard devitation =',round(std,2))
    print("\n===== Kết thúc quá trình tiến hóa")
    best_individual=tools.selBest(population,1)[0]
    print("Thanh niên khỏe nhất:\n",best_individual)
    print("Tổng số 1 trong the choosen one: ",sum(best_individual))