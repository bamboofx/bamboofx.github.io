from simpleai.search import CspProblem,backtrack,min_conflicts,MOST_CONSTRAINED_VARIABLE,HIGHEST_DEGREE_VARIABLE,LEAST_CONSTRAINING_VALUE

# Tạo ràng buộc (contraint-ràng buộc) thứ 1 yêu cầu tất cả các biến trong danh sách input phải là giá trị duy nhất:
def constraint_unique(variables,values):
    #Kiểm tra xem tất cả các giá trị có phải là duy nhất
    return len(values)==len(set(values))
# Tạo ràng buộc thứ 2 yêu cầu biến đầu tiên phải có giá trị lớn hơn biến thứ 2
def constraint_bigger(variables,values):
    return values[0]>values[1]
# Tạo ràng buộc thứ 3 : yêu cầu nếu giá trị biến đầu tiên phải là số lẻ,và giá trị của biến thứ 2 phải là số chẵn và ngược lại:
def contraint_odd_even(variables,values):
    if values[0]%2==0:
        return values[1]%2==1
    else:
        return values[1]%2==0
# Tạo hàm main
if __name__=='__main__':
    variables=('Tèo','Tý','Sửu','Dậu')
    #Tạo danh sách giá trị mà mỗi biến tên có thể lấy
    domain={
        'Tèo':[1,2,3],
        'Tý':[1,3],
        'Sửu':[2,4],
        'Dậu':[2,3,4]}
    contraints=[
       (('Tèo','Tý','Sửu'),constraint_unique),
       (('Sửu','Tý'),constraint_bigger),
       (('Tèo','Dậu'),contraint_odd_even)
   ]
   # Sử dụng các biến và các ràng buộc để tạo 1 object CspProblem:
    problem=CspProblem(variables,domain,contraints)
    # Tính toán các giải pháp và in nó ra Terminal:
    print("Các giải pháp:\n\nNormal:",backtrack(problem))
    # Tính toán các giải pháp sử dụng MOST_CONSTRAINED_VARIABLE
    print("MOST_CONSTRAINED_VARIABLE:",backtrack(problem,value_heuristic=MOST_CONSTRAINED_VARIABLE))
    print("HIGHEST_DEGREE_VARIABLE:",backtrack(problem,value_heuristic=HIGHEST_DEGREE_VARIABLE))
    print("LEAST_CONSTRAINING_VALUE",backtrack(problem,value_heuristic=LEAST_CONSTRAINING_VALUE))
    # Sử dụng kết hợp variable_heuristic và value_heuristic
    print("MOST_CONSTRAINED_VARIABLE,LEAST_CONSTRAINING_VALUE",backtrack(problem,variable_heuristic=MOST_CONSTRAINED_VARIABLE,value_heuristic=LEAST_CONSTRAINING_VALUE))
    print("HIGHEST_DEGREE_VARIABLE,LEAST_CONSTRAINING_VALUE",backtrack(problem,variable_heuristic=HIGHEST_DEGREE_VARIABLE,value_heuristic=LEAST_CONSTRAINING_VALUE))
    #Tính toán các giải pháp sử dụng minimum conflicts heuristic:
    print("Minimum conflicts:",min_conflicts(problem))

