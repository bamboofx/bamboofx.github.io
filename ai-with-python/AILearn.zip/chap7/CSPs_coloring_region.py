from simpleai.search import CspProblem,backtrack

# Tạo hàm ràng buộc yêu cầu giá trị phải khác nhau
def constraint_func(variables,values):
    return values[0]!=values[1]
# Tạo hàm main
if __name__=='__main__':
    # tạo variables cần thiết
    names = ('Mark', 'Julia', 'Steve', 'Amanda', 'Brian', 'Joanne', 'Derek', 'Allan', 'Michelle', 'Kelly')
    # Tạo values với giá trị là các màu cho trước
    colors = dict((name, ['red', 'green', 'blue', 'gray']) for name in names)
    # Chúng ta cần chuyển đổi thông tin đã có vào một thứ để thuật toán có thể hiểu
    # Tạo một ràng buộc điều kiện yêu cầu danh sách những người nằm kế nhau trên bản đồ không có màu trùng nhau
    constraints=[
        (('Mark', 'Julia'), constraint_func), (('Mark', 'Steve'), constraint_func),
        (('Julia', 'Steve'), constraint_func), (('Julia', 'Amanda'), constraint_func),
        (('Julia', 'Derek'), constraint_func), (('Julia', 'Brian'), constraint_func),
        (('Steve', 'Amanda'), constraint_func), (('Steve', 'Allan'), constraint_func),
        (('Steve', 'Michelle'), constraint_func), (('Amanda', 'Michelle'), constraint_func),
        (('Amanda', 'Joanne'), constraint_func), (('Amanda', 'Derek'), constraint_func),
        (('Brian', 'Derek'), constraint_func), (('Brian', 'Kelly'), constraint_func),
        (('Joanne', 'Michelle'), constraint_func), (('Joanne', 'Amanda'), constraint_func),
        (('Joanne', 'Derek'), constraint_func), (('Joanne', 'Kelly'), constraint_func),
        (('Derek', 'Kelly'), constraint_func),
    ]
    # Sử dụng variables ( tên - name) và domain (colors) biến constraints vừa tạo làm tham số cho hàm CspProblem
    problem=CspProblem(names,colors,constraints)
    # Giải quyết vấn đề và in ra phương pháp :
    output=backtrack(problem)
    print('\nColor mapping:\n')
    for k, v in output.items():
        print(k, '==>', v)