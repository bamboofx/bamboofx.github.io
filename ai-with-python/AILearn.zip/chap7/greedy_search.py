import argparse
import simpleai.search as ss

# Tạo một hàm để parser tham số input
def build_arg_parser():
    parser=argparse.ArgumentParser(description='Tạo input string sử dụng thuật toán greedy')
    parser.add_argument("--input-string",dest='input_string',required=True,help='Chuỗi nhập')
    parser.add_argument("--initial-state",dest='initial_state',required=False,default='',help="Điểm bắt đầu tìm kiếm")
    return parser
# Tạo một class chwuas các thuộc tính cần thiết để giải quyết các vấn đề. Class này thừa kế class SearchProblem trong library simpleai. Method đầu tiên set_target là method chúng ta tạo ra để định nghĩa string target
class CustomProblem(ss.SearchProblem):
    def set_target(self,target_string):
        self.target_string=target_string
    # Method actions laf method cos sawnx trong SearchProblem và chúng ta cần override nó. Nó chịu trách nhiệm thực hiện các bước để hướng tới kết quả cuối. Nếu độ dài của chuỗi đang tạo ra nhỏ hơn độ dài của chuỗi đích nó sẽ trả về danh sách bảng chữ cái có thể chọn từ đó. Nếu không nó sẽ trả về chuỗi rỗng (empty string):
    def actions(self, state):
        if len(state)<len(self.target_string):
            alphabets='abcdefghijklmnopqrstuvwxyz '
            return list(alphabets+''+alphabets.upper())
        else:
            return []
    #Method resul là một metod có sẵn của SearchProblem và ta override method để tính toán kết quả bằng cách nối các chuỗi và các hành actions đã lấy trước:
    def result(self, state, action):
        return state+action
    # Method is_goal là method sẵn có của SearchProblem và nó được sử dụng để kiểm tra xem chúng ta đã đến đích chưa
    def is_goal(self, state):
        return state==self.target_string
    # Method heuristic cũng làm method của SearchProblem và chúng ta cũng cần override nó. Chúng ta sẽ định nghĩa lại cái chúng ta cần "khám phá" (heuristic) để giải quyết vấn đề chúng ta gặp phải ( ở đây là xây chuỗi) .
    # Chúng ta sẽ tính toán còn bao nhiêu xa nữa từ trạng thái của chúng ta đang có(current state) để tới đích (goal) và sử dụng số heuristic này để hướng tới đích:
    def heuristic(self, state):
        # So sách chuỗi còn lại với chuỗi đích:
        dist=sum([1 if state[i]!=self.target_string[i] else 0 for i in range(len(state))])
        # Khoảng cách độ dài 2 chuỗi
        diff=len(self.target_string)-len(state)
        return dist+diff

# Tạo hàm main để lấy tham số input
if __name__=='__main__':
    args=build_arg_parser().parse_args()
    customProblem=CustomProblem()
    customProblem.set_target(args.input_string)
    customProblem.initial_state=args.initial_state
    output=ss.greedy(customProblem)
    print('Chuỗi cần tạo ra',args.input_string)
    print('Các phần giải pháp:')
    for item in output.path():
        print(item)

