from simpleai.search import astar,SearchProblem

## Tạo một hàm để chuyển đổi giữa list và tring
def string_to_list(input):
    if isinstance(input,str):
        return [x.split('-') for x in input.split('\n')]
    else:
        return '\n'.join(['-'.join(x) for x in input])
# Tạo hàm kiểm tra vị trí của một ô trong lưới 8x8
def get_location(rows,input_element):
    for i,row in enumerate(rows):
        for j,item in enumerate(row):
            if item==input_element:
                return i,j
#Định nghĩa đích đến cần đạt được
GOAL = '''1-2-3
4-5-6
7-8-e'''
# Tạo vị trí đích đến cho mỗi số để tính khoảng cách
goal_positions = {}
rows_goal = string_to_list(GOAL)
for number in '12345678e':
    goal_positions[number] = get_location(rows_goal, number)

# Tạo class PuzzleSolver chứa các thuộc tính để giải quyết bài toán. class này kế thừa từ class SearchProblem
class PuzzleSolver(SearchProblem):
    #Method actions để lấy danh sách các ô có thể di chuyển tới ô khoảng trống
    def actions(self, state):
        rows=string_to_list(state)
        row_empty,col_empty=get_location(rows,'e')
        # kiểm tra vị trí của ô tróng và tạo action mới:
        actions=[]
        if row_empty>0:
            actions.append(rows[row_empty-1][col_empty])
        if row_empty<2:
            actions.append(rows[row_empty+1][col_empty])
        if col_empty>0:
            actions.append(rows[row_empty][col_empty-1])
        if col_empty<2:
            actions.append(rows[row_empty][col_empty+1])
        return actions
    # Override Method result. Chuyển đổi những chuỗi thành list và lấy vị trí của ô trống. Tạo ra kết quả (result) bằng cách cập nhật vị trí:
    def result(self, state, action):
        rows=string_to_list(state)
        row_empty,col_empty=get_location(rows,'e')
        row_new,col_new=get_location(rows,action)
        rows[row_empty][col_empty],rows[row_new][col_new]=rows[row_new][col_new],rows[row_empty][col_empty]
        return string_to_list(rows)
    # Kiểm tra nếu đã đến được đích
    def is_goal(self, state):
        return state==GOAL
    # Method heuristic. Chúng ta sử dụng heuristic để tính toán khoảng cách từ trạng thái hiện tại đến trạng thái đích sử dụng phép tính khoảng cách Mahattan
    def heuristic(self, state):
        rows=string_to_list(state)
        distance=0
        for number in '12345678e':
            row_new,col_new=get_location(rows,number)
            row_new_goal,col_new_goal=goal_positions[number]
            distance+=abs(row_new-row_new_goal)+abs(col_new-col_new_goal)
        return distance

# Sử dụng A* để khởi tạo vị trí ban đầu
INITIAL = \
'''4-e-3
7-1-5
6-8-2'''
problem=PuzzleSolver(INITIAL)
result=astar(problem)
# In các bước đi
for i,(action,state) in enumerate(result.path()):
    print()
    if action==None:
        print('Hình khởi tạo ban đầu')
    elif i==len(result.path())-1:
        print('Sau khi di chuyển ô',action,'Vào vị trí ô trống. DONE: ')
    else:
        print('Sau khi di chuyển ô', action, 'Vào vị trí ô trống. Ta có')
    print(state)