import nltk
nltk.data.path.append("D:\\PycharmProjects\\AILearn\\NLTK")
from nltk.tokenize import RegexpTokenizer
from nltk.corpus import  stopwords
from nltk.stem.snowball import SnowballStemmer
from gensim import models,corpora

# Tạo một hàm để load dữ liệu. dữ liệu đầu vào gồm có 10 dòng. mỗi dòng là một câu.
def load_data(input_file):
    input_file = open(input_file, 'r', encoding='utf-8')
    # Loại bỏ các dòng
    input_string = input_file.read().splitlines()
    # Join array lại thành string
    input_string = " ".join(input_string)
    import re
    input_string = re.split(r"\.", input_string)
    #input_string = "\n".join(input_string)
    return input_string
# Tạo một hàm để sử lý dữ liệu đầu vào. Bước đầu tiên là phân tách câu (tokenizer)
def progcess(input_text):
    #Regex torkenizer
    tokenizer=RegexpTokenizer(r'\w+')
    # Sau đó chúng ta cần biến nó về dạng từ cơ bản (stem word)
    stemmer = SnowballStemmer('english')
    # Chúng ta cần loại bỏ những từ "dừng" (stopwords) vì nó không cần thiết
    # File stopword-vietnamese lấy ở đây https://github.com/stopwords/vietnamese-stopwords
    with open('data/chap10/vietnamese-stopwords.txt','r',encoding='utf-8') as f:
        stop_word=f.read().splitlines()
    stop_words=set(stop_word)
    #print(stop_word)
    # Tokenizer input
    tokens=tokenizer.tokenize(input_text.lower())
    #print(tokens)
    #loại bỏ stopword
    tokens=[x for x in tokens if not x in stop_words]
    #print(tokens)
    # stem token
    tokens_stemmed=[stemmer.stem(x) for x in tokens]
    return tokens_stemmed
# Tạo hàm main để load dữ liệu
if __name__=="__main__":
    data=load_data("data/chap10/doaremon.txt")
    tokens=[progcess(x) for x in data]
    # Tạo một dict dựa trên những câu đã tokenizer
    dict_tokens=corpora.Dictionary(tokens)
    #Tạo một term matrix sử dụng dict token:
    doc_term_mat=[dict_tokens.doc2bow(token) for token in tokens]
    num_topics=3
    ldamodel = models.ldamodel.LdaModel(doc_term_mat,num_topics=num_topics, id2word=dict_tokens, passes=25)
    num_words = 10
    print('\nTop ' + str(num_words) + ' contributing words to each topic:')
    for item in ldamodel.print_topics(num_topics=num_topics,
                                      num_words=num_words):
        print('\nTopic', item[0])
        #
        list_of_strings = item[1].split(' + ')
        for text in list_of_strings:
            weight = text.split('*')[0]
            word = text.split('*')[1]
            print(word, '==>', str(round(float(weight) * 100, 2)) + '%')