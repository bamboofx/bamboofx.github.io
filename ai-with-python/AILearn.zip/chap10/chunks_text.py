# Tạo hàm chunk để chia dữ liệu input thành những đoạn nhỏ. Tham số đầu tiên là input text và tham số thứ 2 là số từ trong mỗi đoạn
def chunker(input_data,N):
    input_words=input_data.split(' ')
    output=[]
    # Lặp tất cả văn bản để chia chúng vào từng đoạn
    cur_chunk=[]
    count=0
    for word in input_words:
        cur_chunk.append(word)
        count+=1
        if count==N:
            output.append(' '.join(cur_chunk))
            count,cur_chunk=0,[]
    output.append(' '.join(cur_chunk))
    return output
def inputTxt():
    input_file = open("data/chap10/doaremon.txt", 'r', encoding='utf-8')
    # Loại bỏ các dòng
    input_string = input_file.read().splitlines()
    # Join array lại thành string
    input_string=" ".join(input_string)
    import re
    input_string=re.split(r"\.",input_string)
    input_string=" \n".join(input_string)
    return input_string
if __name__=="__main__":
    chunk_size = 100
    chunks=chunker(inputTxt(),chunk_size)
    print(inputTxt())
    print('\nSố mảnh trong đoạn văn =',len(chunks),'\n')
    for i,chunk in enumerate(chunks):
        print("Đoạn",i+1,'==>',chunk[:50])
