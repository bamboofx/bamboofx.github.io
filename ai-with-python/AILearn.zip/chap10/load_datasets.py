from sklearn.datasets import load_files
from pprint import pprint
def LoadFile(folder=""):
    categories=['Am nhac', 'Am thuc', 'Bat dong san', 'Bong da', 'Chung khoan', 'Cum ga', 'Cuoc song do day', 'Du hoc', 'Du lich', 'Duong vao WTO', 'Gia dinh', 'Giai tri tin hoc', 'Giao duc', 'Gioi tinh', 'Hackers va Virus', 'Hinh su', 'Khong gian song', 'Kinh doanh quoc te', 'Lam dep', 'Loi song', 'Mua sam', 'My thuat', 'San khau dien anh', 'San pham tin hoc moi', 'Tennis', 'The gioi tre', 'Thoi trang']
    data=load_files(container_path=folder,categories=categories,encoding='utf-16')
    pprint(data.target)
    return data


LoadFile("data/chap10/Categories_documents/Train/")

