import nltk
nltk.data.path.append("D:\\PycharmProjects\\AILearn\\NLTK")
import random
from nltk import NaiveBayesClassifier
from nltk.classify import accuracy as nacc
from nltk.corpus import names

# tạo một hàm để phân tách ký tự cuối N cho từ được nhập vào
def extract_feature(word,N=2):
    last_n_letters=word[-N:]
    return {'feature':last_n_letters.lower()}
#Tạo hàm main và lấy tên và training nó từ scikit-learn. dữ liệu này gồm tên nam và nữ đã được dán nhãn :
if __name__=="__main__":
    male_list=[(name,'male') for name in names.words('male.txt')]
    female_list=[(name,'female') for name in names.words('female.txt')]

    data=(male_list+female_list)
    # Tạo bộ random number để xáo trộn data:
    random.seed(5)
    random.shuffle(data)
    # Tạo một vài tên để sử dụng test:
    input_names=['Alexander','Danielle','David','Cheryl']
    # Chia dữ liệu để dùng cho train và test:
    num_train=int(0.8*len(data))
    # Chúng ta sẽ sử dụng thuật toán N ký tự cuối như một vector tính năng để dự đoán giới tính. Chúng ta sẽ có một vài tham số để thấy hiệu suất khác nhau. Trường hợp này chúng ta sẽ đi từ 1->6
    for i in range(1,6):
        print("Số ký tự cuối:",i)
        features=[(extract_feature(n,i),gender) for (n,gender) in data]
        # phân chia dữ liệu để train và test
        train_data,test_data= features[:num_train],features[num_train:]

        classifier=NaiveBayesClassifier.train(train_data)
        # Tính toán độ chính xác của bộ phân loại sử dụng hàm có sẵn trong NLTK:
        accuracy=round(100*nacc(classifier,test_data),2)
        print("Độ chính xác =",str(accuracy),'%')
        # Dự đoán kết quả cho mỗi tên chúng ta đã tạo ra
        for name in input_names:
            print(name,"==>",classifier.classify(extract_feature(name,i)))