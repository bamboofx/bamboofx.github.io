import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from chunks_text import chunker,inputTxt

# Tạo cỡ đoạn văn
chunk_size=200
# Chia text thành các đoạn văn:
text_chunk=chunker(inputTxt(),chunk_size)
chunks=[]
for count,chunk in enumerate(text_chunk):
    d={'index':count,'text':chunk}
    chunks.append(d)
# Ta sử dụng hàm CountVectorizer đề đếm số lượng từ và biến đổi chúng thành ma trận số hóa
countvectorizer=CountVectorizer(min_df=5,max_df=20)
#print(chunks)
document_termatrix=countvectorizer.fit_transform(chunk['text'] for chunk in chunks)
vocalbulary=np.array(countvectorizer.get_feature_names())
print("\nVolcabulary\n",vocalbulary)
for i,chunk in enumerate(text_chunk):
    print("Đoạn",i+1,'==>',chunk[:50])
chunk_names = []
for i in range(len(text_chunk)):
    chunk_names.append('Đoạn-' + str(i+1))
# Print the document term matrix
print("\nDocument term matrix:")
formatted_text = '{:>12}' * (len(chunk_names) + 1)
print('\n', formatted_text.format('Word', *chunk_names), '\n')
for word, item in zip(vocalbulary, document_termatrix.T):
    # 'item' is a 'csr_matrix' data structure
    output = [word] + [str(freq) for freq in item.data]
    print(formatted_text.format(*output))
