from sklearn.datasets import load_files
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import SGDClassifier

from nltk import NaiveBayesClassifier
from nltk.classify import accuracy as nacc
from nltk.corpus import names

# Lấy data từ dữ liệu có sẵn ở đây tôi dùng thư viện của VNTC đã tổng hợp từ các trang báo và phân loại sẵn theo thư mục.
# Dữ liệu ở  https://github.com/duyvuleo/VNTC/
train_path="data/chap10/Categories_documents/Train/"
test_path="data/chap10/Categories_documents/Test/"
data_train=load_files(container_path=train_path,encoding='utf-16')
data_test=load_files(container_path=test_path,encoding='utf-16')

# Tách dữ liệu và đếm từ sử dụng CountVectorizer
count_vectorizer=CountVectorizer()
train_tc=count_vectorizer.fit_transform(raw_documents=data_train.data)

# Tạo TF-IDF và train nó dựa trên dữ liệu train text count
tfidf=TfidfTransformer(use_idf=True)
train_tfidf=tfidf.fit_transform(train_tc)

# Cía này là tạo bộ phân loại sử dụng Pipeline
text_clf=Pipeline([('vect', CountVectorizer()), ('tfidf', TfidfTransformer(use_idf=True)), ('clf', SGDClassifier(loss='hinge', penalty='l2', alpha=1e-3, random_state=42, verbose=1)),])
# Tạo một vài dữ liệu để dự đoán
input_data=[
    'Không có nhiều bất ngờ với những cầu thủ vừa được HLV Park Hang-seo bổ sung trong đợt tập trung thứ hai cho vòng loại World Cup 2022',
    'Nghệ sĩ saxophone Xuân Hiếu mất ở tuổi 47 vào trưa 30/9 tại nhà riêng sau thời gian điều trị ung thư.',
    'Xuất hiện trojan giả mạo bản vá của McAfee',
    'Cuộc sống độc thân của Hiền Thục ở Mỹ',
    'Để sở hữu một làn da sáng mịn, ngoài chế độ dinh dưỡng giàu vitamin và khoáng chất, bạn cần thường xuyên vệ sinh sạch sẽ và và duy trì độ ẩm cần thiết cho da.',
    'Những siêu hệ thống giao thông Trung Quốc',
    'Giáo viên trường tiểu học và THCS bán trú Sơn Bua vượt 3 km đường rừng vào các bản làng ở khu dân cư Nước Mù vận động học sinh đến lớp.',
    'Yoshiyuki Kiuchi (49 tuổi) thường cố tình đâm sầm để gây thương tích cho người vừa đi bộ vừa sử dụng điện thoại.',
    'Kinh doanh quán cà phê không là cách đầu tư nhanh có lãi, phải có vốn mạnh và thật kiên nhẫn.',
    'Show diễn của Quang Hà sau vụ cháy'
]
#Sử dụng thuật toán Multinomial Naive Bayes để training data
classifier=MultinomialNB().fit(train_tfidf,data_train.target)
# Sử dụng pipeline để train data. Chú ý data ở đây là data gốc download không phải là data đã được biến đổi
text_clf.fit(data_train.data,data_train.target)
#Biến đổi dữ liệu input sử dụng vectorizer
input_tc=count_vectorizer.transform(input_data)
#print(input_tc)
# Biến đổi dữ liệu sử dụng tfidf để có thể sử dụng với classifer
input_tfidf=tfidf.transform(input_tc)

"""def extract_features(data):
    return {'feature':data.lower()}
for i in range(1,6):
    features=[(extract_features(data_train.data[i]),data_train.target)]
    train_data=features[len(data_train.data)]
    nb_classifier=NaiveBayesClassifier.train(data_train)
    for name in input_data:
        print(name, "==>", nb_classifier.classify(extract_features(name)))
"""

# Dự đoán kết quả sử dụng pipeline
predictions=text_clf.predict(input_data)
# dự đoán kết quả đầu ra sử dụng vector đã được biến đổi dưới dạng tf-idf sử dụng MultinomialNB
#predictions=classifier.predict(input_tfidf)
print(predictions)
#Lấy dữ liệu được dán nhãn từ data đã download
categories=data_train.target_names
# in kết quả
for sent,category in zip(input_data,predictions):
    print("\nĐoạn văn:",sent,"\nDự đoán thể loại:",categories[category])
