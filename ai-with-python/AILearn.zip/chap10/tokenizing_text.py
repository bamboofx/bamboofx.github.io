import nltk
nltk.data.path.append("D:\\PycharmProjects\\AILearn\\NLTK")
from nltk.tokenize import sent_tokenize,word_tokenize,WordPunctTokenizer
# Tạo một đoạn văn bản input để sử dụng tokenization
input_text="Hôm nay trời đẹp, 25* C. Chúng ta nên đi ra ngoài chơi. Hôm qua trời mưa tao ở nhà ngủ. Còn mày có đi chơi không ?"
# Chia đoạn trên thành các câu tokens
print("\nChuyển đoạn văn thành câu:")
print(sent_tokenize(input_text))
# Chia đoạn trên thành các từ
print("\nChuyển đoạn trên thành các từ")
print(word_tokenize(input_text))
# Chia đoạn trên thành các từ sử dụng hàm Word Punct Token
print("Token by WordPunctToken")
print(WordPunctTokenizer().tokenize(input_text))
