import cv2

# Load dữ liệu Haar cascade xml
face_cascade=cv2.CascadeClassifier('../data/chap13/haarcascade/haarcascade_frontalface_default.xml')
# Kiểm tra xem file xml đã đc load hay chưa
if face_cascade.empty():
    raise IOError('Méo có file')

#Khởi tạo các thông số video
cap=cv2.VideoCapture('../data/chap13/congai.mp4')
scale_factor=1

# Tạo vòng lặp để lấy video
while True:
    _,frame=cap.read()
    frame=cv2.resize(frame,None,fx=scale_factor,fy=scale_factor,interpolation=cv2.INTER_AREA)
    # đổi khung hình thành màu xám
    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    # Chạy hàm nhận diện khuôn mặt dựa trên khung hình màu xám
    face_rects=face_cascade.detectMultiScale(gray,1.1,5)
    #Tạo vòng lặp để vẽ hình chữ nhật lên trên khuôn mặt đã phát hiện
    for (x,y,w,h) in face_rects:
        cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255.0,0),2)
    #Hiển thị hình ảnh video
    cv2.imshow("Face detect",frame)
    k=cv2.waitKey(30)
    if k==27:
        break
cap.release()
cv2.destroyAllWindows()


