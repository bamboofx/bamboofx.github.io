import cv2
import numpy as np

# Lấy hàm get_frame từ code cũ
#from frame_differencing import get_frame,movie_path
#Tạo hàm để lấy khung hình
def get_frame(cap:cv2.VideoCapture,scaling_factor):
    try:
        _, frame = cap.read()
        # thu nhỏ khung hình
        frame = cv2.resize(frame, None, fx=scaling_factor, fy=scaling_factor, interpolation=cv2.INTER_AREA)
        return frame
    except:
        gray = None
    return gray
# Tạo hàm main
if __name__=="__main__":
    #Lấy video từ file
    cap=cv2.VideoCapture("../data/chap13/congai.mp4")
    scaling_factor=0.5
    # Tạo vong lặp
    while cap.isOpened():
        frame=get_frame(cap,scaling_factor)
        #Chuyển mã màu sử dụng hàm convert của openCV
        hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
        # Tạo màu gần dúng với màu da của da người
        lower=np.array([0,70,60])
        upper=np.array([50,150,255])
        #Tạo ngưỡng màu trong HSV để tạo lớp mask
        mask=cv2.inRange(hsv,lower,upper)
        # Tính toán sự khác nhau giữa 2 khung hình sử dụng mask và thuật toán bitwise_and cảu openCV
        img_out=cv2.bitwise_and(frame,frame,mask=mask)
        # sử dụng median blurring để làm đẹp hình
        img_blurring=cv2.medianBlur(img_out,5)
        # Hiển thị hình ảnh
        cv2.imshow("Input",frame)
        cv2.imshow("Output",img_blurring)
        # Tạo wait key để chờ
        k=cv2.waitKey(10)
        if k==27:
            break
    cap.release()
    cv2.destroyAllWindows()

