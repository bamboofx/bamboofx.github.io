import cv2
import numpy as np

# Lấy hàm getframe của phần trước
from object_tracking_withcolor import get_frame

#Tạo hàm main
if __name__=="__main__":
    cap=cv2.VideoCapture("../data/chap13/congai.mp4")
    # Tạo object background subtractor lấy từ OpenCV
    bg_sub=cv2.createBackgroundSubtractorMOG2()
    # Tạo một lịch sử hình ảnh để học
    history=100
    # Tạo một số của những khung hình trước để học, yếu tố này kiểm soát việc tần suất học của thuật toán.
    # Tần suất học là tần suất mà mô hình của bạn sẽ học về hình nền. Giá tị cao đồng nghĩa với việc tần suất học chậm
    # Bạn có thể thay đổi giá trị để xem sự khác biệt của việc tách nền.
    learning_rate=1.0/history
    # Tạo vòng lặp
    while cap.isOpened():
        frame=get_frame(cap,0.5)
        # Tính toán mask sử dụng object tách nền đã định nghĩa ở trên
        mask=bg_sub.apply(frame,learningRate=learning_rate)
        # Mask ở đây là dạng màu xám chúng ta cần chuyển nó lại thành dạng RGB
        mask=cv2.cvtColor(mask,cv2.COLOR_GRAY2BGR)
        # Hiển thị kết quả
        cv2.imshow("Input",frame)
        cv2.imshow("Output",mask&frame)
        k=cv2.waitKey(10)
        if k==27:
            break
    cap.release()
    cv2.destroyAllWindows()

