import cv2
import numpy as np

# Tạo một hàm bắt đầu để theo dõi vật thể sự dụng optical flow.
def start_tracking():
    cap=cv2.VideoCapture("../data/chap13/sample.mp4")
    scaling_factor=0.5
    #Tạo số frame sẽ theo dõi và số frames bỏ qua
    num_frames_to_track=5
    num_frames_jump=2
    # Tạo biến đường theo dõi và frame index:
    tracking_paths=[]
    frame_index=0
    #tạo các tham số dùng để theo dõi sử dụng thuật toán calcOpticalFlowPyrLK của openCV
    #* window size: kích cỡ ô theo dõi
    #* maxLevel
    #* (temrmination criteria)
    tracking_params=dict(winSize=(6,6),maxLevel=5,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,10,0.03))
    # Tạo vòng Lặp
    while True:
        # Lấy khung hình
        _,frame=cap.read()
        # Resize
        frame=cv2.resize(frame,None,fx=scaling_factor,fy=scaling_factor,interpolation=cv2.INTER_AREA)
        # đổi màu
        frame_gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        #Tạo một copy của khung hình
        output_img=frame.copy()
        # Kiểm tra xem độ dài của path đã tạo có lớn hơn 0 thì lấy hình ảnh

        if len(tracking_paths)>0:
            prev_img,current_img=prev_gray,frame_gray
            # Tạo các điểm đặc trưng:
            feature_points_0=np.float32([tp[-1] for tp in tracking_paths]).reshape(-1,1,2)
            # Tính optical flow dựa trên những khung hình trước và khung hình hiện tại sử dụng các điểm đặc trưng và các tham số đã tạo
            feature_points_1,_,_=cv2.calcOpticalFlowPyrLK(prev_img,current_img,feature_points_0,None,**tracking_params)
            # Tạo một hàm tính ngược optical flow
            feature_points_0_rev,_,_=cv2.calcOpticalFlowPyrLK(current_img,prev_img,feature_points_1,None,**tracking_params)
            # Tính toán điểm khác nhau giữa 2 phép tính optical flow lấy số dương
            diff_feature_points=abs(feature_points_1-feature_points_0_rev).reshape(-1,2).max(-1)
            # Lấy những điểm có giá trị tốt
            good_points=diff_feature_points<1
            #Tạo tracking path mới
            new_tracking_paths=[]
            # Lặp mảng good_points để vẽ hình lên đó
            for tp,(x,y),good_points_flag in zip(tracking_paths,feature_points_1.reshape(-1,2),good_points):
                if not good_points_flag:
                    continue
                tp.append((x,y))
                if len(tp)>num_frames_to_track:
                    del tp[0]
                new_tracking_paths.append(tp)
                # Vẽ hình
                cv2.circle(output_img,(x,y),1,(0,255,0),-1)
                # cập nhật tracking path
            tracking_paths=new_tracking_paths
            # Vẽ đường thằng nối các điểm
            cv2.polylines(output_img,[np.int32(tp) for tp in tracking_paths],False,(0,150,0))
        if not frame_index%num_frames_jump:
            # Tạo mask và vẽ vòng tròn
            mask=np.zeros_like(frame_gray)
            mask[:]=255
            for x,y in[np.int32(tp[-1]) for tp in tracking_paths]:
                cv2.circle(mask,(x,y),6,0,-1)
                # Sử dụng hàm có sẵn của openCV đỉ tính các điểm đặc trưng
            feature_points=cv2.goodFeaturesToTrack(frame_gray,mask=mask,maxCorners=100,qualityLevel=0.3,minDistance=5,blockSize=3)

            # Nếu có những điểm đặc trưng giá trị tốt thì thêm nó vào tracking path
            if feature_points is not None:
                for m,n in np.float32(feature_points).reshape(-1,2):
                    tracking_paths.append([(m,n)])
        frame_index+=1
        prev_gray=frame_gray
        # Hiển thị hình ảnh
        cv2.imshow("Optical Flow", output_img)
        # Tạo waitKey
        k=cv2.waitKey(1)
        if k==27:
            break

if __name__ == '__main__':
    start_tracking()
    cv2.destroyAllWindows()


