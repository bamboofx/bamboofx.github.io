import cv2

# Load dữ liệu Haar cascade xml
#cv2.data.haarcascades

# Load dữ liệu eye xml
face_cascade=cv2.CascadeClassifier('../data/chap13/haarcascade/haarcascade_frontalface_alt.xml')
eyes_cascade=cv2.CascadeClassifier('../data/chap13/haarcascade/haarcascade_eye_tree_eyeglasses.xml')
nose_cascade=cv2.CascadeClassifier('../data/chap13/haarcascade/haarcascade_mcs_nose.xml')


# Kiểm tra xem file xml face đã đc load hay chưa
if face_cascade.empty():
    raise IOError('Méo có face file')
# Kiểm tra xem file xml face đã đc load hay chưa
if eyes_cascade.empty():
    raise IOError('Méo có file eye xml')

if nose_cascade.empty():
    raise IOError('Méo có file nose xml')

#Khởi tạo các thông số video
cap=cv2.VideoCapture('../data/chap13/sample.mp4')
scale_factor=0.5

# Tạo vòng lặp để lấy video
while True:
    hasFrame,frame=cap.read()
    if not hasFrame:
        cv2.waitKey()
        break
    frame=cv2.resize(frame,None,fx=scale_factor,fy=scale_factor,interpolation=cv2.INTER_AREA)
    # đổi khung hình thành màu xám
    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    # Chạy hàm nhận diện khuôn mặt dựa trên khung hình màu xám
    face_rects=face_cascade.detectMultiScale(gray,scaleFactor=1.2,minNeighbors=5,minSize=(5,5),flags=cv2.CASCADE_SCALE_IMAGE)
    #Tạo vòng lặp để vẽ hình chữ nhật lên trên khuôn mặt đã phát hiện
    for (x,y,w,h) in face_rects:
        cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255.0,0),2)
        # Dựa vào vị trí của face để lấy vị trí của mắt dựa trên face - ĐỔi màu face thành gray luôn
        face_gray=gray[y:y+h,x:x+w]
        # Lấy mặt có màu
        face_color=frame[y:y+h,x:x+w]
        #TÌm vị trí của mắt
        eyes=eyes_cascade.detectMultiScale(face_gray)
        nose=nose_cascade.detectMultiScale(face_gray)

        # Vẽ vòng tròn quanh mắt
        for (x_eye,y_eye,w_eye,h_eye) in eyes:
            center=(int(x_eye+w_eye/2),int(y_eye+h_eye/2))
            radius=int(0.3*(w_eye+h_eye))
            color=(255,0,0)
            cv2.circle(face_color,center=center,radius=radius,color=color,thickness=2)
        #Vẽ mũi
        for (x_n,y_n,w_n,h_n) in nose:
            cv2.rectangle(face_color,(x_n,y_n),(x_n+w_n,y_n+w_n),(0,0,255),thickness=3)
    #Hiển thị hình ảnh video
    cv2.imshow("Face detect",frame)
    k=cv2.waitKey(10)
    if k==27:
        break
cap.release()
cv2.destroyAllWindows()


