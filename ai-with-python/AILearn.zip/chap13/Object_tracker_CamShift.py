import cv2
import numpy as np

#Tạo một class để quản lý tất cả các hàm sử dụng để theo dõi vật thể:
class ObjectTracker(object):
    def __init__(self,scaling_factor=0.5):
        #Tạo object cap để lấy video source
        self.cap=cv2.VideoCapture("../data/chap13/sample.mp4")
        self.startTrack=False
        # Lấy khung hình hiện tại
        _,self.frame=self.cap.read()
        self.scaling_factor=scaling_factor
        # Resize khung hình dựa trên scaling_factor
        self.frame=cv2.resize(self.frame,None,fx=self.scaling_factor,fy=self.scaling_factor,interpolation=cv2.INTER_AREA)
        # Tạo một cửa sổ để hiển thị khung hình
        cv2.namedWindow("Object Tracker")
        # Tạo hàm callback để lẩy dữ liệu hoạt động của mouse
        cv2.setMouseCallback("Object Tracker",self.mouse_event)
        # Tạo các biến cho class để theo dõi select của mouse
        self.selection=None
        self.drag_start=None
        self.tracking_state=0



    #Tạo hàm lấy event của mouse
    def mouse_event(self,event,x,y,flags,param):
        # Chuyển đổi giá trị tọa độ x,y của mouse thành dạng 16 bit
        x,y=np.int16([x,y])
        # khi chúng ta bấm chuột có nghĩa là bắt đầu lựa chọn khung để chọn vật thể
        #if event==cv2.EVENT_LBUTTONUP:

        if event==cv2.EVENT_LBUTTONDOWN:
            self.drag_start=(x,y)
            self.tracking_state=0

        if self.drag_start:
            if flags&cv2.EVENT_FLAG_LBUTTON:
                #Lấy chiều dài,rộng của khung hình hiện tại
                h,w=self.frame.shape[:2]
                # Tính điểm tọa độ X,Y của khung hình
                xi,yi=self.drag_start
                # Tính toán vị trí nhỏ nhất và lớn nhất của vị trí kéo chuột dựa trên trục tọa độ để tính vùng chọn
                x0,y0=np.maximum(0,np.minimum([xi,yi],[x,y]))
                x1,y1=np.minimum([w,h],np.maximum([xi,yi],[x,y]))
                self.selection=None
                if x1-x0>0 and y1-y0>0:
                    self.selection=(x0,y0,x1,y1)
                # Sao khi hoàn tất tính toán vị trí của vùng chọn thì đặt flag và chúng ta bắt đầu theo dõi vật thể dựa theo vùng chọn
            else:
                self.drag_start=None
                if self.selection is not None:
                    self.tracking_state=1
    # Tạo hàm theo dõi vật thể:
    def start_tracking(self):
        while True:
            _,self.frame=self.cap.read()
            self.frame=cv2.resize(self.frame,None,fx=self.scaling_factor,fy=self.scaling_factor,interpolation=cv2.INTER_AREA)
            # Tạo một bản sao cho khung hình hiện tại chúng ta sẽ sử dụng nó sau
            vis=self.frame.copy()
            # Chuyển đổi màu từ RGB thành HSV
            hsv=cv2.cvtColor(self.frame,cv2.COLOR_BGR2HSV)
            # Tạo mask dựa trên ngưỡng màu xác định trước
            lower=np.array((0.,0.,0.))
            upper=np.array((255.,255.,255.))
            mask=cv2.inRange(hsv,lowerb=lower,upperb=upper)
            #Kiểm tra xem người dùng đã chọn vùng chọn chưa : ?

            if self.selection:
                x0,y0,x1,y1=self.selection
                # tạo vùng chọn

                self.track_window=(x0,y0,x1-x0,y1-y0)
                # Tạo vùng chọn từ hình HSV như là một mask. Tính toán biểu đồ màu dựa trên vùng đó
                hsv_roi=hsv[y0:y1,x0:x1]
                mask_roi=mask[y0:y1,x0:x1]
                histogram=cv2.calcHist([hsv_roi],[0],mask_roi,[16],[0,180])
                cv2.normalize(histogram,histogram,0,255,cv2.NORM_MINMAX)
                self.hist=histogram.reshape(-1)
                vis_roi=vis[y0:y1,x0:x1]
                # Tính toán sử dụng bitwise_not của vùng chọn
                cv2.bitwise_not(vis_roi,vis_roi)
                vis[mask==0]=0
            if self.tracking_state==1:
                self.selection=None
                hsv_backproj=cv2.calcBackProject([hsv],[0],self.hist,[0,180],1)
                hsv_backproj&=mask
                # Chấm dứt theo dõi
                term_crit=(cv2.TERM_CRITERIA_EPS|cv2.TermCriteria_COUNT,10,1)
                #Áp dụng thuật toán CamShift
                track_box,self.track_window=cv2.CamShift(hsv_backproj,self.track_window,term_crit)
                # Vẽ hình ellip xung quanh vật theo dõi và hiển thị nó lên một cửa số
                cv2.ellipse(vis,track_box,(0,255,0),thickness=2)
            cv2.imshow("Object Tracker",vis)
            # Tạo escape
            k=cv2.waitKey(30)
            if k==27:
                break
        self.cap.release()
        cv2.destroyAllWindows()

# Tạo hàm main để chạy
if __name__=="__main__":
    ob=ObjectTracker(1)
    ob.start_tracking()
