import cv2
import os.path as path
#Tạo hàm để tính toán khác biệt của các khung hình. Bắt đầu bằng cách tính toán sự khác nhau giữa khung hình hiện tại và khung hình kế tiếp
def movie_path() ->str:
    return path.join("../data/chap13/congai.mp4")
def frame_dif(prev_frame,cur_frame,next_frame):
    diff_frames_1=cv2.absdiff(next_frame,cur_frame)
    #Tính toán sự khác nhau giữa khung hình hiện tại và khung hình trước đó
    diff_frames_2=cv2.absdiff(cur_frame,prev_frame)
    #sử dụng phép tính toán trên bit (bitwise) của openCV để tính toán sự khác nhau giữa các frames và trả lại giá trị đó
    return cv2.bitwise_and(diff_frames_1,diff_frames_2)
#Tạo hàm để lấy khung hình hiện tại từ video.
def get_frame(cap:cv2.VideoCapture,scaling_factor):

    try:
        _,frame=cap.read()
        # thu nhỏ khung hình

        frame=cv2.resize(frame,None,fx=scaling_factor,fy=scaling_factor,interpolation=cv2.INTER_AREA)
        # Chuyển đổi frame sang màu xám
        gray=cv2.cvtColor(frame,cv2.COLOR_RGBA2GRAY)
        print(gray)
    except:
        gray=None
    return gray
#Tạo hàm main để lấy video
if __name__=="__main__":
    cap=cv2.VideoCapture(movie_path());
    scaling_factor=1
    #Lấy khung hình hiện tại current frame, khung hình kế tiếp và khung hình trước (prev_frame,next frame)
    prev_frame=get_frame(cap,scaling_factor)
    cur_frame=get_frame(cap,scaling_factor)
    next_frame=get_frame(cap,scaling_factor)
    # Tạo vòng lặp tới khi kết thúc video
    while cap.isOpened():
        # đọc khung hình biến đầu tiên là giá trị boolean retval trả về True khi có thể đọc được video
        ret,frame=cap.read()
        print(ret)
        if ret:
            cv2.imshow('Theo dõi chuyển động',frame_dif(prev_frame,cur_frame,next_frame))
            #Cập nhật frame
            prev_frame=cur_frame
            cur_frame=next_frame
            next_frame=get_frame(cap,scaling_factor)
            #Tạo waitkey để break (27 = keycode escape)
            key=cv2.waitKey(100)
            if key==27:
                break
        else:
            break
    # khi hết vòng lặp cần phải đóng video và destroy window
    cap.release()
    cv2.destroyAllWindows()